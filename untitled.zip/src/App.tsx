import React, { useState, useEffect, Suspense, lazy } from 'react';
import { 
  Menu, X, Search, 
  ArrowUpRight, ArrowUp, Phone, MessageSquare, MapPin, Check, Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { ThemeStyles } from './ThemeStyles';
import { portfolioData, categories } from './data';
import { 
  useIntersectionObserver, Reveal 
} from './components1';
import { WebDevBanner, WebDevServices, DigitalMarketingBanner, DigitalMarketingServices, WhyChooseDezo, ProcessSectionPRD, StatsSection, FaqSection, TestimonialsSection } from './components/PRDSections';
import { AnimatedHeroVisual, PortfolioImageWithFallback, ContactBackgroundVisual } from './components/AnimatedVisuals';
import { AnimatedFavicon } from './AnimatedFavicon';

import { HeroSection } from './components/HeroSection';
const AboutUsPage = lazy(() => import('./AboutUsPage').then(m => ({ default: m.AboutUsPage })));
const NotFoundPage = lazy(() => import('./NotFoundPage').then(m => ({ default: m.NotFoundPage })));

const WebDevPage = lazy(() => import('./pages').then(m => ({ default: m.WebDevPage })));
const BbsrWebDevPage = lazy(() => import('./pages').then(m => ({ default: m.BbsrWebDevPage })));
const DigitalMarketingPage = lazy(() => import('./pages').then(m => ({ default: m.DigitalMarketingPage })));
const SeoServicesPage = lazy(() => import('./pages').then(m => ({ default: m.SeoServicesPage })));
const MetaAdsPage = lazy(() => import('./pages').then(m => ({ default: m.MetaAdsPage })));
const GoogleAdsPage = lazy(() => import('./pages').then(m => ({ default: m.GoogleAdsPage })));
const EcommercePage = lazy(() => import('./pages').then(m => ({ default: m.EcommercePage })));
const LandingPagePage = lazy(() => import('./pages').then(m => ({ default: m.LandingPagePage })));
const BlogPage = lazy(() => import('./pages').then(m => ({ default: m.BlogPage })));
const ContactPage = lazy(() => import('./pages').then(m => ({ default: m.ContactPage })));
const PortfolioPage = lazy(() => import('./pages').then(m => ({ default: m.PortfolioPage })));
const ServicesPage = lazy(() => import('./pages').then(m => ({ default: m.ServicesPage })));
const ToolsPage = lazy(() => import('./pages').then(m => ({ default: m.ToolsPage })));
const NewsPage = lazy(() => import('./pages').then(m => ({ default: m.NewsPage })));
const FaqPage = lazy(() => import('./pages').then(m => ({ default: m.FaqPage })));
const PricingPage = lazy(() => import('./pages').then(m => ({ default: m.PricingPage })));
const ResourcesPage = lazy(() => import('./pages').then(m => ({ default: m.ResourcesPage })));
const PrivacyPage = lazy(() => import('./pages').then(m => ({ default: m.PrivacyPage })));
const TermsPage = lazy(() => import('./pages').then(m => ({ default: m.TermsPage })));

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);
  return null;
};

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isDesktop, setIsDesktop] = useState(true);
  
  const [activeCategory, setActiveCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAllProjects, setShowAllProjects] = useState(false);
  const [selectedProject, setSelectedProject] = useState<any>(null);

  useEffect(() => {
    document.body.classList.remove('night-mode');
  }, []);
  
  const [formData, setFormData] = useState({
    name: '', email: '', phone: '', businessName: '', city: '', service: '', budget: '', message: ''
  });
  const [formErrors, setFormErrors] = useState<any>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(min-width: 1024px)');
    setIsDesktop(mediaQuery.matches);
    
    const handleResize = (e: MediaQueryListEvent) => setIsDesktop(e.matches);
    mediaQuery.addEventListener('change', handleResize);
    
    document.title = "Dezo | Web Development & Digital Marketing Agency India";

    let tickingScroll = false;
    const handleScroll = () => {
      if (!tickingScroll) {
        window.requestAnimationFrame(() => {
          setScrolled(window.scrollY > 20);
          tickingScroll = false;
        });
        tickingScroll = true;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      mediaQuery.removeEventListener('change', handleResize);
    };
  }, []);

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [mobileMenuOpen]);

  const handleFormChange = (e: any) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (formErrors[e.target.name]) setFormErrors({ ...formErrors, [e.target.name]: '' });
  };

  const handleFormSubmit = async (e: any) => {
    e.preventDefault();
    const errors: any = {};
    if (!formData.name) errors.name = "Please fill in your name.";
    if (!formData.phone) errors.phone = "Please fill in your phone number.";
    if (!formData.email) errors.email = "Please fill in your email address.";
    else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email)) errors.email = "Invalid email format.";
    if (!formData.service) errors.service = "Please select a service.";
    if (!formData.message) errors.message = "Please write a short message.";
    
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    
    setIsSubmitting(true);
    
    // Fire the email request in the background
    fetch("https://formsubmit.co/ajax/princetarikislam@gmail.com", {
      method: "POST",
      headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
      },
      body: JSON.stringify({
          _subject: "New Lead from DEZO Website",
          _template: "table",
          Name: formData.name,
          Email: formData.email,
          Phone: formData.phone,
          "Business Name": formData.businessName || 'N/A',
          City: formData.city || 'N/A',
          Budget: formData.budget || 'N/A',
          Service: formData.service,
          Message: formData.message,
      })
    }).catch(() => {});

    setIsSubmitting(false);
    setIsSubmitted(true);
    
    const whatsappMessage = `Hi DEZO, I want a website.
Name: ${formData.name}
Phone: ${formData.phone}
Business: ${formData.businessName || 'N/A'}
Website Type: ${formData.service}
Budget: ${formData.budget || 'N/A'}
Message: ${formData.message}`;

    const whatsappUrl = `https://wa.me/919114411026?text=${encodeURIComponent(whatsappMessage)}`;
    
    window.open(whatsappUrl, '_blank');
    
    setTimeout(() => setIsSubmitted(false), 8000);
    setFormData({ name: '', email: '', phone: '', businessName: '', city: '', service: '', budget: '', message: '' });
  };

  const filteredPortfolio = portfolioData.filter(item => {
    const matchesCategory = activeCategory === "All" || item.category === activeCategory;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) || item.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const highlightedProjects = [
    "Great India Public School", "Sorobana Abacus Academy", 
    "Yasana Beauty Rituals", "Aura Mantra", "Zavique", 
    "Sonvica Sarees"
  ].map(title => portfolioData.find(p => p.title === title)).filter(Boolean);

  const navigate = useNavigate();
  const location = useLocation();

  const handleNavClick = (e: any, item: string) => {
    // Preserving function signature to avoid changing where it might be used
    setMobileMenuOpen(false);
  };

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Services', path: '/services' },
    { label: 'Portfolio', path: '/portfolio' },
    { label: 'Pricing', path: '/pricing' },
    { label: 'Tools', path: '/tools' },
    { label: 'News', path: '/news' },
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' }
  ];

  const handleLogoClick = (e: any) => {
    e.preventDefault();
    if (location.pathname !== '/') {
      navigate('/');
      window.scrollTo({top: 0});
    } else {
      window.scrollTo({top: 0, behavior: 'smooth'});
    }
  };

  return (
    <div className="min-h-screen bg-[var(--bg-main)] text-[var(--text-main)] font-sans scroll-smooth relative">
      <ThemeStyles />
      <AnimatedFavicon />

      <header className={`fixed top-0 left-0 right-0 z-[60] transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-[0_4px_20px_rgba(15,23,42,0.05)] border-b border-[#E5EAF2]' : 'bg-transparent'}`}>
        <div className={`max-w-[90rem] mx-auto px-4 lg:px-8 flex justify-between items-center transition-all duration-300 ${scrolled ? 'py-3' : 'py-4 lg:py-6'}`}>
          <a href="#" className="flex items-center gap-2 z-[70] group" aria-label="Dezo Home" onClick={handleLogoClick}>
            <span className="font-black text-3xl tracking-[0.2em] text-[#0B1220] transition-all duration-300">DEZO</span>
          </a>

          <nav className={`hidden lg:flex items-center space-x-7 ${scrolled ? '' : 'bg-white/80 border border-[#E5EAF2] backdrop-blur-md px-8 py-3.5 rounded-full shadow-sm'} transition-all duration-300`}>
            {navLinks.map((item) => (
              <Link 
                key={item.path} 
                to={item.path} 
                onClick={() => window.scrollTo(0,0)}
                className="text-xs font-bold uppercase tracking-[0.15em] text-[#5B6472] hover:text-[#1D4ED8] transition-all duration-300"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-4">
            <a href="#contact" onClick={(e) => {
              if (window.location.pathname === '/') {
                e.preventDefault();
                document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
              } else {
                window.location.href = '/#contact';
              }
            }} className="btn-primary px-7 py-3 text-sm">
              Get Free Consultation
            </a>
          </div>

          <button aria-label="Toggle Mobile Menu" aria-expanded={mobileMenuOpen} className="lg:hidden p-2 z-[70] active:scale-90 transition-all duration-300" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X size={28} className="text-[#0B1220]" /> : <Menu size={28} className="text-[#0B1220]" />}
          </button>
        </div>

        {/* Mobile Navigation Drawer */}
        <div className={`fixed inset-0 bg-white z-[65] lg:hidden flex flex-col justify-center px-6 transition-all duration-300 transform ${mobileMenuOpen ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0 pointer-events-none'}`}>
          <button aria-label="Close Mobile Menu" className="absolute top-4 right-4 p-2 z-[70] active:scale-90 transition-all duration-300" onClick={() => setMobileMenuOpen(false)}>
            <X size={28} className="text-[#0B1220]" />
          </button>
          <div className="flex flex-col space-y-6 text-center mt-16">
            {navLinks.map((item, i) => (
               <Link 
                 key={item.path} 
                 to={item.path} 
                 onClick={() => { setMobileMenuOpen(false); window.scrollTo(0, 0); }}
                 className="text-2xl font-black tracking-tight text-[#0B1220] hover:text-[#1D4ED8] transition-all duration-300" 
                 style={{ transitionDelay: `${i * 50}ms` }}
               >
                {item.label}
              </Link>
            ))}
            <a href="#contact" onClick={(e) => {
              setMobileMenuOpen(false);
              if (window.location.pathname === '/') {
                e.preventDefault();
                document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
              } else {
                window.location.href = '/#contact';
              }
            }} className="mt-8 px-8 py-4 btn-primary text-lg mx-auto inline-block">
              Get Free Consultation
            </a>
          </div>
        </div>
      </header>

      <ScrollToTop />
      <Suspense fallback={<div className="min-h-screen section-dark flex items-center justify-center"></div>}>
      <Routes>
        <Route path="/" element={
          <main>
          <HeroSection />

      {/* TRUST BADGES STRIP */}
      <section className="py-6 section-dark border-b border-[var(--border-soft)] overflow-hidden">
        <div className="max-w-[90rem] mx-auto px-4">
          <div className="flex flex-wrap justify-center items-center gap-x-8 gap-y-4 text-center divide-x divide-white/10 opacity-80">
             <div className="px-4 flex items-center gap-2">
               <div className="text-[var(--primary)]"><Check size={20} /></div>
               <div className="text-xs font-bold text-[var(--text-main)] uppercase tracking-widest leading-snug">Fast Loading Websites</div>
             </div>
             <div className="px-4 flex items-center gap-2">
               <div className="text-[var(--primary)]"><Check size={20} /></div>
               <div className="text-xs font-bold text-[var(--text-main)] uppercase tracking-widest leading-snug">Mobile-First Design</div>
             </div>
             <div className="px-4 flex items-center gap-2">
               <div className="text-[var(--primary)]"><Check size={20} /></div>
               <div className="text-xs font-bold text-[var(--text-main)] uppercase tracking-widest leading-snug">SEO-Ready Structure</div>
             </div>
             <div className="px-4 flex items-center gap-2 hidden md:flex">
               <div className="text-[var(--primary)]"><Check size={20} /></div>
               <div className="text-xs font-bold text-[var(--text-main)] uppercase tracking-widest leading-snug">Premium UI/UX</div>
             </div>
             <div className="px-4 flex items-center gap-2 hidden lg:flex">
               <div className="text-[var(--primary)]"><Check size={20} /></div>
               <div className="text-xs font-bold text-[var(--text-main)] uppercase tracking-widest leading-snug">WhatsApp Lead Focus</div>
             </div>
             <div className="px-4 flex items-center gap-2 hidden lg:flex">
               <div className="text-[var(--primary)]"><Check size={20} /></div>
               <div className="text-xs font-bold text-[var(--text-main)] uppercase tracking-widest leading-snug">Business Growth Support</div>
             </div>
          </div>
        </div>
      </section>

      <WebDevBanner />
      <WebDevServices />
      <DigitalMarketingBanner />
      <DigitalMarketingServices />

      {/* 7. PORTFOLIO - LIGHTWEIGHT FOR HOME */}
      <section id="latest-work" className="py-20 lg:py-32 section-dark border-y border-[var(--border-soft)] overflow-hidden">
        <div className="max-w-[90rem] mx-auto px-4 lg:px-8">
          <Reveal direction="up">
            <h2 className="clamp-h2 font-black text-[var(--text-main)] mb-12 text-center tracking-tight uppercase px-2">OUR LATEST WEBSITE PROJECTS</h2>
          </Reveal>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {highlightedProjects.slice(0, 6).map((project: any, i: number) => (
              <Reveal direction="up" delay={i * 50} key={i}>
                <div className="block h-full group pb-4">
                  <article 
                    className="bg-transparent h-full flex flex-col relative"
                  >
                    <div className="relative w-full aspect-video rounded-xl overflow-hidden mb-5 border border-[var(--border-soft)] bg-[var(--bg-surface)] group-hover:border-[var(--primary)]/30 smooth-transition">
                      <PortfolioImageWithFallback title={project.title} src={`https://api.microlink.io/?url=${encodeURIComponent(project.url)}&screenshot=true&meta=false&embed=screenshot.url`} alt={project.title} />
                      <div className="absolute top-4 left-4">
                        <div className="text-[10px] font-bold text-[var(--text-main)] uppercase bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">{project.category}</div>
                      </div>
                    </div>
                    <div className="relative z-10 flex flex-col flex-1">
                      <h4 className="text-xl md:text-2xl font-bold text-[var(--text-main)] group-hover:text-[var(--primary)] mb-2 line-clamp-1 smooth-transition">{project.title}</h4>
                      <div className="text-[13px] text-[var(--text-muted)] font-medium mb-4 line-clamp-2">Premium {project.category.toLowerCase()} web application built for speed and conversions.</div>
                      
                      <div className="mt-auto flex justify-between items-center gap-3">
                        <button onClick={() => setSelectedProject(project)} className="flex-1 py-3 text-center text-xs font-bold text-[var(--text-main)] bg-[var(--bg-card)] border border-[var(--border-soft)] hover:border-[var(--primary)]/50 rounded-lg hover:text-[var(--primary)] smooth-transition flex items-center justify-center gap-1">Details <ArrowUpRight size={14} /></button>
                        <a href={`https://wa.me/919114411026?text=Hi%20DEZO%2C%20I%20like%20the%20${encodeURIComponent(project.title)}%20project.%20I%20want%20to%20get%20a%20similar%20website.`} target="_blank" rel="noopener noreferrer" className="flex-1 py-3 text-center text-xs font-bold text-[#070707] bg-[var(--primary)] hover:bg-[var(--accent)] rounded-lg smooth-transition">Get Similar</a>
                      </div>
                    </div>
                  </article>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal direction="up" delay={200}>
            <div className="mt-12 flex justify-center">
              <Link to="/portfolio" onClick={() => window.scrollTo(0,0)} className="btn-primary px-8 py-4">
                View Full Portfolio
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      <WhyChooseDezo />
      
      <ProcessSectionPRD />
      
      <TestimonialsSection />
      
      <div id="pricing-wrapper">
      </div>

      <StatsSection />

      {/* 12. Lead Form / CONTACT */}
      <section id="contact" className="py-24 lg:py-32 section-dark overflow-hidden relative">
        <ContactBackgroundVisual />
        <div className="max-w-[90rem] mx-auto px-4 lg:px-8 relative z-10">
          <Reveal direction="scale">
            <div className="bg-[var(--bg-card)] rounded-[2.5rem] p-6 lg:p-16 border border-[var(--border-soft)] shadow-xl relative overflow-hidden flex flex-col lg:flex-row gap-12 lg:gap-16">
              <div className="lg:w-1/3 relative z-10 flex flex-col justify-start pt-4">
                   <h2 className="clamp-h2 font-black text-[#0B1220] mb-4 tracking-tight">Start Growing With Dezo Today</h2>
                  <p className="text-[var(--text-muted)] mb-10 font-medium">Ready to take your digital presence to the next level? Reach out to us today.</p>
                  
                  <div className="space-y-8">
                    <div>
                      <h4 className="text-xs font-bold text-[#0B1220] uppercase tracking-[0.2em] mb-2 opacity-50">DEZO Expert Team</h4>
                      <p className="text-xl font-black text-[var(--primary)]">Ready to Build Your Digital Future</p>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-[var(--text-main)] uppercase tracking-[0.2em] mb-2 opacity-50">Contact Info</h4>
                      <div className="flex flex-col gap-2">
                        <a href="tel:+919114411026" className="text-[var(--text-main)] font-bold hover:text-[var(--accent)] smooth-transition flex items-center gap-2">
                          <Phone size={16} /> +91 91144 11026
                        </a>
                        <a href="mailto:princetarikislam@gmail.com" className="text-[var(--text-main)] font-bold hover:text-[var(--accent)] smooth-transition flex items-center gap-2">
                          <MessageSquare size={16} /> princetarikislam@gmail.com
                        </a>
                        <a href="mailto:contact@dezo.in" className="text-[var(--text-main)] font-bold hover:text-[var(--accent)] smooth-transition flex items-center gap-2">
                          <MessageSquare size={16} /> contact@dezo.in
                        </a>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-[var(--text-main)] uppercase tracking-[0.2em] mb-2 opacity-50">Address</h4>
                      <div className="flex items-start gap-2">
                        <MapPin size={18} className="text-[var(--text-main)] mt-1 shrink-0" />
                        <p className="text-[var(--text-main)] font-bold leading-relaxed">
                          Phase 2, Patia<br/>
                          Bhubaneswar, Odisha<br/>
                          751024, India
                        </p>
                      </div>
                    </div>
                  </div>
              </div>
              
              <div className="lg:w-2/3 relative z-10">
                <form className="space-y-5" onSubmit={handleFormSubmit}>
                {isSubmitted && <div className="bg-[var(--primary)]/10 text-[var(--accent)] p-4 rounded-xl text-sm font-bold border border-[var(--primary)]/20">Form submitted successfully! We'll get back to you shortly.</div>}
                {formErrors.general && <div className="bg-red-500/10 text-red-400 p-4 rounded-xl text-sm font-bold border border-red-500/20">{formErrors.general}</div>}
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="nameInput" className="text-[10px] font-bold uppercase tracking-widest mb-2 block text-[var(--text-main)] relative">Name <span className="text-red-500">*</span></label>
                    <input id="nameInput" name="name" type="text" value={formData.name} onChange={handleFormChange} className="w-full bg-[var(--bg-surface)] border border-[var(--border-soft)] rounded-xl px-5 focus:border-[var(--primary)] min-h-[56px] text-sm text-[var(--text-main)] focus:outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/20 smooth-transition" placeholder="Full Name / Company Name" />
                    {formErrors.name && <p className="text-red-500 text-xs font-bold mt-1.5">{formErrors.name}</p>}
                  </div>
                  <div>
                    <label htmlFor="emailInput" className="text-[10px] font-bold uppercase tracking-widest mb-2 block text-[var(--text-main)]">Email <span className="text-red-500">*</span></label>
                    <input id="emailInput" name="email" type="email" value={formData.email} onChange={handleFormChange} className="w-full bg-[var(--bg-surface)] border border-[var(--border-soft)] rounded-xl px-5 focus:border-[var(--primary)] min-h-[56px] text-sm text-[var(--text-main)] focus:outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/20 smooth-transition" placeholder="Official Email Address" />
                    {formErrors.email && <p className="text-red-500 text-xs font-bold mt-1.5">{formErrors.email}</p>}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="phoneInput" className="text-[10px] font-bold uppercase tracking-widest mb-2 block text-[var(--text-main)]">Phone <span className="text-red-500">*</span></label>
                    <input id="phoneInput" name="phone" type="tel" value={formData.phone} onChange={handleFormChange} className="w-full bg-[var(--bg-surface)] border border-[var(--border-soft)] rounded-xl px-5 focus:border-[var(--primary)] min-h-[56px] text-sm text-[var(--text-main)] focus:outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/20 smooth-transition" placeholder="Phone Number / WhatsApp" />
                    {formErrors.phone && <p className="text-red-500 text-xs font-bold mt-1.5">{formErrors.phone}</p>}
                  </div>
                  <div>
                    <label htmlFor="businessInput" className="text-[10px] font-bold uppercase tracking-widest mb-2 block text-[var(--text-main)]">Business Type</label>
                    <input id="businessInput" name="businessName" type="text" value={formData.businessName} onChange={handleFormChange} className="w-full bg-[var(--bg-surface)] border border-[var(--border-soft)] rounded-xl px-5 focus:border-[var(--primary)] min-h-[56px] text-sm text-[var(--text-main)] focus:outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/20 smooth-transition" placeholder="e.g. Real Estate, E-commerce, School" />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="budgetInput" className="text-[10px] font-bold uppercase tracking-widest mb-2 block text-[var(--text-main)]">Budget Range</label>
                    <select id="budgetInput" name="budget" value={formData.budget} onChange={handleFormChange} className="w-full bg-[var(--bg-surface)] border border-[var(--border-soft)] rounded-xl px-5 focus:border-[var(--primary)] min-h-[56px] text-sm text-[var(--text-main)] appearance-none focus:outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/20 smooth-transition" style={{ backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'rgba(255,255,255,0.7)\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6 9 12 15 18 9\'%3e%3c/polyline%3e%3c/svg%3e")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1em' }}>
                      <option value="">Select Budget (Optional)</option>
                      <option value="₹4,999 - ₹10,000">₹4,999 - ₹10,000</option>
                      <option value="₹10,000 - ₹25,000">₹10,000 - ₹25,000</option>
                      <option value="₹25,000+">₹25,000+</option>
                      <option value="Flexible">Flexible</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="serviceInput" className="text-[10px] font-bold uppercase tracking-widest mb-2 block text-[var(--text-main)]">Website Type Needed <span className="text-red-500">*</span></label>
                    <select id="serviceInput" name="service" value={formData.service} onChange={handleFormChange} className="w-full bg-[var(--bg-surface)] border border-[var(--border-soft)] rounded-xl px-5 focus:border-[var(--primary)] min-h-[56px] text-sm text-[var(--text-main)] appearance-none focus:outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/20 smooth-transition" style={{ backgroundImage: 'url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'rgba(255,255,255,0.7)\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3e%3cpolyline points=\'6 9 12 15 18 9\'%3e%3c/polyline%3e%3c/svg%3e")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1em' }}>
                      <option value="">Select Website Type</option>
                      <option value="Starter Business Website">Starter Business Website</option>
                      <option value="Advanced Agency / Scaling Website">Advanced Agency / Scaling Website</option>
                      <option value="Ecommerce Website">Ecommerce Website</option>
                      <option value="Landing Page">Landing Page</option>
                      <option value="Digital Marketing / Meta Ads">Digital Marketing / Meta Ads</option>
                      <option value="Other">Other</option>
                    </select>
                    {formErrors.service && <p className="text-red-500 text-xs font-bold mt-1.5">{formErrors.service}</p>}
                  </div>
                </div>

                <div>
                  <label htmlFor="messageInput" className="text-[10px] font-bold uppercase tracking-widest mb-2 block text-[var(--text-main)]">Project Details <span className="text-red-500">*</span></label>
                  <textarea id="messageInput" name="message" value={formData.message} onChange={handleFormChange} rows={4} className="w-full bg-[var(--bg-surface)] border border-[var(--border-soft)] rounded-xl px-5 focus:border-[var(--primary)] py-4 text-sm text-[var(--text-main)] focus:outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/20 smooth-transition resize-vertical" placeholder="Tell us what you want to build..."></textarea>
                  {formErrors.message && <p className="text-red-500 text-xs font-bold mt-1.5">{formErrors.message}</p>}
                </div>
                
                <div className="pt-2 flex flex-col sm:flex-row gap-4">
                  <button type="submit" disabled={isSubmitting} className="flex-1 w-full min-h-[60px] rounded-xl bg-[var(--primary)] text-[#070707] font-black text-lg tracking-wide hover:bg-[var(--accent)] hover:-translate-y-1 active:translate-y-0 active:scale-95 smooth-transition flex items-center justify-center gap-2 disabled:opacity-70 disabled:pointer-events-none">
                    {isSubmitting ? (
                      <>Sending...</>
                    ) : (
                      "Send Project Enquiry"
                    )}
                  </button>
                  <button type="button" onClick={() => window.open('https://wa.me/919114411026', '_blank')} className="flex-1 w-full min-h-[60px] rounded-xl bg-[#25D366] text-[#070707] font-black text-lg tracking-wide hover:shadow-lg hover:-translate-y-1 active:translate-y-0 active:scale-95 smooth-transition flex items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 1.833 6.368L.141 24l5.803-1.492A12 12 0 1 0 11.944 0zm0 22C6.918 22 2.802 18.237 2.451 13.315l1.637 1.636a8.878 8.878 0 0 1 10.9-10.9l1.636-1.636C12.186 2.012 11.968 2 11.944 2c-5.522 0-10 4.477-10 10 0 1.76.452 3.411 1.233 4.887L1.93 21.365l4.63-1.196A9.957 9.957 0 0 0 11.944 22c5.522 0 10-4.478 10-10s-4.478-10-10-10zm5.176-6.425c-.282-.141-1.669-.824-1.927-.919-.258-.094-.447-.141-.635.141-.188.282-.729.919-.894 1.107-.165.188-.33.211-.612.07-.282-.141-1.19-.439-2.268-1.4-8.37-1.135 7.42-1.925 7.185-1.442-.236.483-3.692.671-5.127.812-.141.141-.33.353-.33.353s-.188.165-.188.447c0 .282.188.635.423.824.236.188.236.47.236.753.047.893-1.011 2.585-2.067 2.679-1.011.094-1.364.094-1.904-.094s-.541-.47-.541-.894.236-1.011.682-1.364c.541-.423.705-.682.894-1.152.188-.47.094-.894-.047-1.176-.141-.282-.635-1.528-.87-2.092-.235-.564-.47-.487-.635-.494-.165-.008-.353-.008-.541-.008s-.494.07-.753.353c-.258.282-1.011.988-1.011 2.4 0 1.411 1.035 2.775 1.176 2.963.141.188 2.022 3.081 4.891 4.316.682.294 1.223.47 1.646.6.682.216 1.305.185 1.796.113.551-.082 1.669-.682 1.904-1.34s.235-1.223.165-1.341c-.07-.118-.258-.188-.541-.33z"/></svg>
                    Chat on WhatsApp
                  </button>
                </div>
              </form>
            </div>
          </div>
          </Reveal>
        </div>
      </section>

      {/* 13. FAQ Section */}
      <FaqSection />
      
      </main>
        } />
        <Route path="/web-development-company-india" element={<WebDevPage />} />
        <Route path="/website-development-bhubaneswar" element={<BbsrWebDevPage />} />
        <Route path="/digital-marketing-agency-india" element={<DigitalMarketingPage />} />
        <Route path="/seo-services-india" element={<SeoServicesPage />} />
        <Route path="/meta-ads-agency-india" element={<MetaAdsPage />} />
        <Route path="/google-ads-agency-india" element={<GoogleAdsPage />} />
        <Route path="/ecommerce-website-development" element={<EcommercePage />} />
        <Route path="/landing-page-design-services" element={<LandingPagePage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/portfolio" element={<PortfolioPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/about" element={<AboutUsPage onBack={() => { navigate('/'); window.scrollTo({top: 0}); }} />} />
        <Route path="*" element={<NotFoundPage />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/tools" element={<ToolsPage />} />
        <Route path="/news" element={<NewsPage />} />
        <Route path="/faq" element={<FaqPage />} />
        <Route path="/pricing" element={<PricingPage />} />
        <Route path="/resources" element={<ResourcesPage />} />
        <Route path="/privacy-policy" element={<PrivacyPage />} />
        <Route path="/terms-conditions" element={<TermsPage />} />
      </Routes>
      </Suspense>
      
      {/* FOOTER */}
      <footer className="section-dark pt-20 lg:pt-28 pb-10 border-t border-[var(--border-soft)]">
          <div className="max-w-[90rem] mx-auto px-4 lg:px-8">
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-8 mb-16">
                  <div className="col-span-2 lg:col-span-1">
                    <span className="font-black text-2xl tracking-[0.2em] text-[#0B1220] mb-4 block">DEZO</span>
                    <p className="text-[var(--text-muted)] text-sm font-medium mb-6">A premium web development and digital marketing agency delivering scalable solutions for brands across India.</p>
                    <div className="flex gap-4 text-[var(--text-main)]/70 text-sm font-bold">
                        <a href="https://wa.me/919114411026" className="hover:text-[var(--primary)] smooth-transition cursor-pointer">WhatsApp</a>
                        <a href="mailto:contact@dezo.in" className="hover:text-[var(--primary)] smooth-transition cursor-pointer">Email</a>
                    </div>
                  </div>
                  <div className="lg:ml-auto">
                    <h4 className="text-[#0B1220] font-bold mb-4 uppercase tracking-widest text-xs">Services</h4>
                    <ul className="space-y-3 text-sm text-[var(--text-muted)] font-medium">
                      <li><Link to="/web-development-company-india" className="hover:text-[var(--primary)] smooth-transition">Web Development</Link></li>
                      <li><Link to="/ecommerce-website-development" className="hover:text-[var(--primary)] smooth-transition">Ecommerce Websites</Link></li>
                      <li><Link to="/landing-page-design-services" className="hover:text-[var(--primary)] smooth-transition">Landing Pages</Link></li>
                      <li><Link to="/digital-marketing-agency-india" className="hover:text-[var(--primary)] smooth-transition">Digital Marketing</Link></li>
                      <li><Link to="/seo-services-india" className="hover:text-[var(--primary)] smooth-transition">SEO Services</Link></li>
                      <li><Link to="/meta-ads-agency-india" className="hover:text-[var(--primary)] smooth-transition">Meta Ads</Link></li>
                    </ul>
                  </div>
                  <div className="lg:ml-auto">
                    <h4 className="text-[#0B1220] font-bold mb-4 uppercase tracking-widest text-xs">Menu</h4>
                    <ul className="space-y-3 text-sm text-[var(--text-muted)] font-medium">
                      <li><Link to="/about" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">About Us</Link></li>
                      <li><Link to="/portfolio" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">Portfolio</Link></li>
                      <li><Link to="/blog" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">Insights</Link></li>
                      <li><Link to="/tools" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">Free Tools</Link></li>
                      <li><Link to="/news" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">News & Updates</Link></li>
                      <li><Link to="/faq" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">FAQ</Link></li>
                      <li><Link to="/pricing" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">Pricing</Link></li>
                    </ul>
                  </div>
                  <div className="lg:ml-auto">
                    <h4 className="text-[#0B1220] font-bold mb-4 uppercase tracking-widest text-xs">Resources</h4>
                    <ul className="space-y-3 text-sm text-[var(--text-muted)] font-medium">
                      <li><Link to="/resources" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">Free Resources</Link></li>
                      <li><Link to="/privacy-policy" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">Privacy Policy</Link></li>
                      <li><Link to="/terms-conditions" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">Terms & Conditions</Link></li>
                    </ul>
                  </div>
                  <div className="lg:ml-auto">
                    <h4 className="text-[#0B1220] font-bold mb-4 uppercase tracking-widest text-xs">Contact</h4>
                    <ul className="space-y-3 text-sm text-[var(--text-muted)] font-medium">
                      <li>+91 91144 11026</li>
                      <li>contact@dezo.in</li>
                      <li><Link to="/contact" onClick={() => window.scrollTo(0,0)} className="hover:text-[var(--primary)] smooth-transition">Contact Us</Link></li>
                      <li className="pt-2">Phase 2, Patia<br/>Bhubaneswar, Odisha<br/>751024, India</li>
                    </ul>
                  </div>
              </div>
              <div className="flex flex-col md:flex-row justify-between items-center text-center text-xs font-bold text-[var(--text-main)]/40 border-t border-[var(--border-soft)] pt-8">
                  <p>© {new Date().getFullYear()} DEZO Agency. All rights reserved.</p>
                  <p className="mt-2 md:mt-0">Premium Digital Solutions in India.</p>
              </div>
          </div>
      </footer>

      {/* Portfolio Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-[0_10px_40px_rgba(0,0,0,0.5)] border border-[var(--border-soft)] relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button 
                onClick={() => setSelectedProject(null)}
                className="absolute top-4 right-4 w-10 h-10 bg-[var(--gold-glow)] hover:bg-white/10 rounded-full flex items-center justify-center smooth-transition z-10"
              >
                <X size={20} className="text-[#0B1220]" />
              </button>
              
              <div className="flex flex-col md:flex-row">
                <div className="w-full md:w-1/2 min-h-[300px] md:min-h-[500px] section-dark relative overflow-hidden flex items-center justify-center p-8">
                  <div className="absolute inset-0 bg-gradient-to-br from-[var(--primary)]/10 to-[var(--accent)]/10"></div>
                  <div className="relative z-10 text-center">
                    <h3 className="text-3xl font-black text-[var(--text-main)] opacity-50">{selectedProject.title}</h3>
                    <p className="font-bold text-[var(--text-muted)] mt-4 tracking-widest uppercase text-xs">Preview Area</p>
                  </div>
                </div>
                
                <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col justify-center bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)]">
                  <div className="mb-6">
                    <span className="text-[10px] font-bold text-[var(--primary)] uppercase bg-[var(--primary)]/10 px-3 py-1 rounded-full border border-[var(--primary)]/20 inline-block mb-3">{selectedProject.category}</span>
                    <h2 className="text-3xl font-black text-[var(--text-main)] mb-4 drop-shadow-sm">{selectedProject.title}</h2>
                    <p className="text-[var(--text-muted)] font-medium mb-6 leading-relaxed">
                      A premium, completely responsive website built for maximum conversion. This project features mobile-first architecture, strict SEO adherence, and lightning-fast loading speeds on all devices.
                    </p>
                  </div>
                  
                  <div className="space-y-3 mb-8">
                    <div className="flex items-center gap-3">
                      <Check size={18} className="text-[var(--success-green)]" />
                      <span className="font-bold text-sm text-[#F4F4F5]">Responsive Mobile-First Design</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Check size={18} className="text-[var(--success-green)]" />
                      <span className="font-bold text-sm text-[#F4F4F5]">High-Converting Call to Actions</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Check size={18} className="text-[var(--success-green)]" />
                      <span className="font-bold text-sm text-[#F4F4F5]">On-Page SEO Optimized</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row gap-3">
                    <a 
                      href={selectedProject.url !== "#" ? selectedProject.url : '#'} 
                      target={selectedProject.url !== "#" ? "_blank" : "_self"} 
                      rel="noopener noreferrer" 
                      className="px-6 py-3.5 section-dark hover:bg-[var(--gold-glow)] text-white text-sm font-bold uppercase tracking-widest rounded-xl text-center smooth-transition flex-1 whitespace-nowrap"
                    >
                      Visit Live Site
                    </a>
                    <a 
                      href={`https://wa.me/919114411026?text=Hi%20DEZO%2C%20I%20want%20a%20website%20similar%20to%20${encodeURIComponent(selectedProject.title)}.`}
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="px-6 py-3.5 bg-[var(--primary)] text-[#070707] text-sm font-bold uppercase tracking-widest rounded-xl text-center smooth-transition flex-1 whitespace-nowrap shadow-md hover:shadow-lg hover:-translate-y-0.5"
                    >
                      Get Similar Site
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="pb-20 md:pb-0"></div>
      {/* Mobile Sticky CTA */}
      <AnimatePresence>
        {scrolled && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
            className="md:hidden fixed bottom-4 left-4 right-4 z-[80] flex gap-3 pb-[env(safe-area-inset-bottom)]"
          >
            <motion.a 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="#pricing"
              className="flex-[0.4] section-dark/95 backdrop-blur-2xl border border-[var(--border-soft)] text-[var(--text-main)] font-bold text-center py-4 rounded-2xl flex items-center justify-center gap-2 shadow-2xl shadow-black/50"
            >
              <span className="text-base font-black text-gradient-main">₹4,999</span>
            </motion.a>
            <motion.a 
              animate={{ 
                scale: [1, 1.03, 1],
              }}
              transition={{
                scale: { repeat: Infinity, duration: 2, ease: "easeInOut" }
              }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              href="https://wa.me/919114411026"
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 bg-[#25D366] text-white font-black text-center py-4 rounded-2xl flex items-center justify-center gap-3 shadow-2xl shadow-[#25D366]/20 relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12.012 2c-5.523 0-10 4.477-10 10 0 1.76.452 3.411 1.233 4.887L1.93 21.365l4.63-1.196A9.957 9.957 0 0 0 12.012 22c5.522 0 10-4.478 10-10s-4.478-10-10-10zm0 2c4.411 0 8 3.589 8 8s-3.589 8-8 8a7.95 7.95 0 0 1-4.704-1.536l-3.696.953.953-3.696A7.95 7.95 0 0 1 4.012 12c0-4.411 3.589-8 8-8zm-1.176 11.575c-.282.141-1.669.824-1.927.919-.258.094-.447.141-.635-.141-.188-.282-.729-.919-.894-1.107-.165-.188-.33-.211-.612-.07-.282-.141-1.19-.439-2.268-1.4-8.37-1.135 7.42-1.925 7.185-1.442-.236.483-3.692.671-5.127.812-.141.141-.33.353-.33.353s-.188.165-.188.447c0 .282.188.635.423.824.236.188.236.47.236.753.047.893-1.011 2.585-2.067 2.679-1.011.094-1.364.094-1.904-.094s-.541-.47-.541-.894.236-1.011.682-1.364c.541-.423.705-.682.894-1.152.188-.47.094-.894-.047-1.176-.141-.282-.635-1.528-.87-2.092-.235-.564-.47-.487-.635-.494-.165-.008-.353-.008-.541-.008s-.494.07-.753.353c-.258.282-1.011.988-1.011 2.4 0 1.411 1.035 2.775 1.176 2.963.141.188 2.022 3.081 4.891 4.316.682.294 1.223.47 1.646.6.682.216 1.305.185 1.796.113.551-.082 1.669-.682 1.904-1.34s.235-1.223.165-1.341c-.07-.118-.258-.188-.541-.33z"/></svg>
              <span className="text-sm">WhatsApp Chat</span>
            </motion.a>
          </motion.div>
        )}
      </AnimatePresence>


    </div>
  );
}
