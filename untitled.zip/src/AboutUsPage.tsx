import React from 'react';
import { ArrowLeft, Target, ShieldCheck, Zap, Users, Sparkles, CheckCircle2 } from 'lucide-react';
import { Reveal } from './components1';
import { ThemeStyles } from './ThemeStyles';
import { AnimatedAgencyWorkflow } from './components/AnimatedVisuals';

export const AboutUsPage = ({ onBack }: { onBack: () => void }) => {
  return (
    <main className="bg-[var(--bg-surface)] min-h-screen pt-24 pb-32">
      <div className="max-w-[70rem] mx-auto px-4 lg:px-8">
        
        <Reveal direction="down">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-[var(--text-main)] font-bold hover:text-[var(--primary)] smooth-transition mb-12 group"
          >
            <div className="w-10 h-10 rounded-full bg-[var(--bg-card)] border border-[var(--border-soft)] flex justify-center items-center group-hover:border-[var(--primary)] group-hover:bg-[var(--primary)]/5 smooth-transition">
              <ArrowLeft size={18} />
            </div>
            Back to Home
          </button>
        </Reveal>

        <Reveal direction="up">
          <div className="text-center mb-16">
            <h1 className="clamp-h1 font-black text-[var(--text-main)] mb-4 relative inline-block">
              <span className="leading-tight block text-[var(--primary)]">About DEZO</span>
            </h1>
          </div>
        </Reveal>

        <div className="space-y-12 text-lg md:text-xl text-[var(--text-secondary)] leading-relaxed font-medium">
          
          <Reveal direction="up" delay={100}>
            <div className="bg-[var(--bg-card)] p-10 md:p-14 rounded-[2.5rem] border border-[var(--border-soft)] shadow-sm relative overflow-hidden group">
              <p className="mb-6">
                DEZO is a modern web development and digital marketing company based in Bhubaneswar, Odisha. We help businesses build premium websites, improve search visibility, run better ads, and create a stronger digital presence.
              </p>
              <p>
                Whether you need a fast business website, an e-commerce platform, or a lead-generating landing page, our team is focused on delivering clean design and reliable technical performance.
              </p>
            </div>
          </Reveal>

          <Reveal direction="up" delay={150}>
             <AnimatedAgencyWorkflow />
          </Reveal>

          <Reveal direction="up" delay={200}>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-[var(--bg-card)] p-10 rounded-[2rem] border border-[var(--border-soft)] hover:border-[var(--primary)]/30 smooth-transition shadow-sm">
                <div className="w-14 h-14 bg-[var(--primary)]/10 text-[var(--primary)] rounded-full flex items-center justify-center mb-6">
                  <Target size={28} />
                </div>
                <h3 className="text-2xl font-black mb-4 text-[var(--text-main)]">Focus on Quality</h3>
                <p>
                  Your website is often the first impression a customer has of your business. We build websites that look professional, load quickly, and are easy for your customers to use, helping you build immediate trust.
                </p>
              </div>

              <div className="bg-[var(--bg-card)] p-10 rounded-[2rem] border border-[var(--border-soft)] hover:border-[var(--primary)]/30 smooth-transition shadow-sm">
                <div className="w-14 h-14 bg-[var(--primary)]/10 text-[var(--primary)] rounded-full flex items-center justify-center mb-6">
                  <Zap size={28} />
                </div>
                <h3 className="text-2xl font-black mb-4 text-[var(--text-main)]">End-to-End Solutions</h3>
                <p>
                  Beyond web development, we provide complete digital marketing systems including SEO, Meta Ads, and Google Ads management to make sure your newly built website actually reaches your target audience and generates leads.
                </p>
              </div>
            </div>
          </Reveal>

          <Reveal direction="up" delay={400}>
            <div className="bg-[var(--bg-card)] p-10 md:p-14 rounded-[2.5rem] border border-[var(--border-soft)] shadow-sm relative overflow-hidden group">
              <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
                <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden shrink-0 shadow-[0_0_20px_rgba(29,78,216,0.2),0_0_40px_rgba(245,179,1,0.1)] border-2 border-[var(--primary)]/50 relative">
                  <div className="absolute inset-0 rounded-full border border-[var(--accent)]/30 scale-105 pointer-events-none"></div>
                  <a href="https://ibb.co/vvC6hbT3" target="_blank" rel="noopener noreferrer" className="block w-full h-full relative z-10">
                    <img src="https://i.ibb.co/1JYtM3Pr/Whats-App-Image-2026-05-08-at-9-13-17-AM-1.jpg" alt="Tarik Islam Director" className="w-full h-full object-cover" />
                  </a>
                </div>
                <div>
                  <h3 className="text-3xl font-black text-[var(--text-main)] mb-2">Tarik Islam</h3>
                  <p className="text-[var(--text-secondary)] font-bold uppercase tracking-widest text-sm mb-6">Director & CEO</p>
                  <p className="mb-4">
                    DEZO was founded to provide businesses with a reliable, transparent, and high-quality partner for digital growth. Under Tarik's leadership, DEZO focuses on creating fast, responsive, and marketing-ready websites.
                  </p>
                  <p className="text-[var(--text-secondary)] italic border-l-4 border-[var(--border-soft)] pl-4">
                    "We build digital presence that helps businesses grow steadily. No shortcuts, just hard work, clean design, and reliable technology."
                  </p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </main>
  );
};
