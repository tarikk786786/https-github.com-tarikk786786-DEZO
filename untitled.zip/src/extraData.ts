export const toolsData = [
  { id: 'website-audit', title: 'Website Audit Tool', description: 'Analyze your website for performance, SEO, and security issues.', icon: 'Search' },
  { id: 'seo-checker', title: 'SEO Checker', description: 'Check your on-page SEO score and get actionable tips.', icon: 'TrendingUp' },
  { id: 'speed-checker', title: 'Speed Checker', description: 'Test your website load speed across devices.', icon: 'Zap' },
  { id: 'cost-calculator', title: 'Project Cost Calculator', description: 'Estimate the cost of your web development or marketing project.', icon: 'Code' },
];

export const blogPosts = [
  { id: 'fast-website', title: 'Why Every Business Needs a Fast Website', category: 'Web Development', date: 'May 15, 2026', excerpt: 'Speed is not just a technical metric; it is a critical business metric. Learn how a fast website improves conversion rates.' },
  { id: 'seo-basics', title: 'SEO Basics for Local Business Growth', category: 'SEO', date: 'May 10, 2026', excerpt: 'A comprehensive guide to dominating local search engine results and driving foot traffic to your local business.' },
  { id: 'meta-ads-leads', title: 'How Meta Ads Help Generate Leads', category: 'Digital Marketing', date: 'May 5, 2026', excerpt: 'Discover advanced strategies for maximizing ROAS on Facebook and Instagram, and turning clicks into qualified leads.' },
  { id: 'website-mistakes', title: 'Website Design Mistakes to Avoid', category: 'UI/UX Design', date: 'April 28, 2026', excerpt: 'Avoid these common website design pitfalls that can ruin your conversion rate and user trust.' },
  { id: 'mobile-speed', title: 'Why Mobile Speed Matters', category: 'Performance', date: 'April 20, 2026', excerpt: 'Over 80% of traffic is mobile. If your site takes more than 3 seconds to load on a phone, you are losing customers.' },
];

export const newsUpdates = [
  { id: 'dezo-launch', title: 'DEZO Officially Launches New Service Packages', date: 'May 1, 2026', type: 'Company Update' },
  { id: 'ai-integration', title: 'Introducing AI Integration for Client Websites', date: 'April 20, 2026', type: 'Product Update' },
  { id: 'award-nomination', title: 'DEZO Nominated for Best Emerging Agency', date: 'April 5, 2026', type: 'Industry News' },
];

export const faqData = [
  { q: "How long does a website take?", a: "For a standard business website or landing page, we usually deliver within 1 to 2 weeks. Custom platforms, e-commerce stores, or complex websites may take 4 to 8 weeks depending on the features." },
  { q: "Do you provide SEO?", a: "Yes, every website we build includes foundational technical SEO to ensure Google can properly read it. We also offer dedicated monthly SEO services to help you rank higher for competitive industry keywords." },
  { q: "Can you redesign an old website?", a: "Absolutely. We specialize in taking outdated websites and modernizing them for better speed, mobile responsiveness, and higher conversion rates. We ensure your existing SEO value is preserved during the transition." },
  { q: "Do you manage Meta Ads?", a: "Yes, we run and manage targeted Facebook and Instagram (Meta) Ads. We don't just set up the campaigns; we design the ad creatives, write the copy, and engineer the landing pages to maximize your return on ad spend." },
  { q: "Is the website mobile-friendly?", a: "100%. Over 70% of web traffic comes from mobile devices, so we design with a 'mobile-first' approach. Your website will look perfect and load instantly on all smartphones and tablets." },
  { q: "Can it be hosted on Vercel or Netlify?", a: "Yes. Our modern React and Next.js applications are perfectly optimized for edge-hosting platforms like Vercel and Netlify, providing you with incredible load speeds and enterprise-grade security." },
  { q: "Do you provide maintenance?", a: "Yes, we offer ongoing support and maintenance packages. We handle updates, security patches, backups, and minor content changes so you can entirely focus on running your business." }
];
