import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { ArrowRight, Orbit } from 'lucide-react';
import { motion } from 'motion/react';

const earthVertexShader = `
    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vPosition;
    varying vec3 vSunDirection;
    void main() {
        vUv = uv;
        vNormal = normalize(normalMatrix * normal);
        vPosition = position;
        vec3 sunPos = vec3(12.0, 4.0, 8.0); // Directional light source vector mapping
        vSunDirection = normalize(sunPos - (modelViewMatrix * vec4(position, 1.0)).xyz);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
`;

const earthFragmentShader = `
    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vPosition;
    varying vec3 vSunDirection;

    // GPU friendly Pseudo-random Simplex Fractal Brownian Motion implementation
    float hash(vec3 p) {
        p = fract(p * 0.3183099 + vec3(0.1, 0.1, 0.1));
        p *= 17.0;
        return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
    }

    float noise(in vec3 x) {
        vec3 i = floor(x);
        vec3 f = fract(x);
        f = f*f*(3.0-2.0*f);
        return mix(mix(mix(hash(i+vec3(0,0,0)), hash(i+vec3(1,0,0)),f.x),
                       mix(hash(i+vec3(0,1,0)), hash(i+vec3(1,1,0)),f.x),f.y),
                   mix(mix(hash(i+vec3(0,0,1)), hash(i+vec3(1,0,1)),f.x),
                       mix(hash(i+vec3(0,1,1)), hash(i+vec3(1,1,1)),f.x),f.y),f.z);
    }

    float fbm(vec3 p) {
        float v = 0.0;
        float a = 0.5;
        vec3 shift = vec3(100.0);
        for (int i = 0; i < 6; ++i) {
            v += a * noise(p);
            p = p * 2.0 + shift;
            a *= 0.5;
        }
        return v;
    }

    void main() {
        // Calculate basic light incidence
        float incidence = dot(vNormal, vSunDirection);
        
        // Fetch procedural land elevations 
        float elevation = fbm(vPosition * 2.5);
        float landMask = smoothstep(0.42, 0.46, elevation);

        // Ocean, land, and city lights values
        vec3 oceanColor = vec3(0.04, 0.11, 0.28);
        vec3 deepOceanColor = vec3(0.02, 0.05, 0.15);
        vec3 landColor = vec3(0.15, 0.28, 0.18);
        vec3 sandColor = vec3(0.35, 0.32, 0.22);
        vec3 cityLightColor = vec3(0.98, 0.85, 0.45);

        // Blend realistic terrains based on elevation noise
        vec3 daySurface = mix(mix(deepOceanColor, oceanColor, elevation * 1.5), mix(sandColor, landColor, elevation), landMask);

        // Setup complex golden night lights along coastline areas
        float coastLights = smoothstep(0.35, 0.45, elevation) * (1.0 - smoothstep(0.45, 0.48, elevation));
        vec3 nightSurface = mix(vec3(0.005, 0.01, 0.03), cityLightColor, coastLights * 0.7);

        // Draw final composite terrain color gradient
        vec3 finalSurface = mix(nightSurface, daySurface, smoothstep(-0.15, 0.25, incidence));

        // Add sunrise rim glow/terminator highlighting
        float rimGlow = smoothstep(0.0, 0.05, incidence) * (1.0 - smoothstep(0.05, 0.45, incidence));
        finalSurface += vec3(0.22, 0.74, 0.97) * rimGlow * 0.7;

        gl_FragColor = vec4(finalSurface, 1.0);
    }
`;

export const HeroAnimation = () => {
    const starCanvasRef = useRef<HTMLCanvasElement>(null);
    const threeContainerRef = useRef<HTMLDivElement>(null);
    const textBlockRef = useRef<HTMLDivElement>(null);
    
    useEffect(() => {
        let mouseX = 0, mouseY = 0;
        let targetMouseX = 0, targetMouseY = 0;
        let scrollY = window.scrollY;

        const handleMouseMove = (e: MouseEvent) => {
            targetMouseX = (e.clientX - window.innerWidth / 2) / (window.innerWidth / 2);
            targetMouseY = (e.clientY - window.innerHeight / 2) / (window.innerHeight / 2);
        };

        const handleScroll = () => {
            scrollY = window.scrollY;
        };

        const handleDeviceOrientation = (e: DeviceOrientationEvent) => {
            if (e.beta && e.gamma) {
                targetMouseX = e.gamma / 45; 
                targetMouseY = (e.beta - 45) / 45;
            }
        };

        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('scroll', handleScroll);
        window.addEventListener('deviceorientation', handleDeviceOrientation);

        // ==================== BACKGROUND SPACE CANVAS ====================
        const starCanvas = starCanvasRef.current;
        if (!starCanvas) return;
        const starCtx = starCanvas.getContext('2d');
        if (!starCtx) return;

        let starPoints: any[] = [];
        let shootingStar: any = null;

        const generateStars = () => {
            starPoints = [];
            const count = window.innerWidth < 768 ? 100 : 350;
            for (let i = 0; i < count; i++) {
                starPoints.push({
                    x: Math.random() * starCanvas.width,
                    y: Math.random() * starCanvas.height,
                    size: Math.random() * 1.5,
                    opacity: Math.random(),
                    twinkleSpeed: 0.005 + Math.random() * 0.015,
                    depth: 0.2 + Math.random() * 0.8
                });
            }
        };

        const resizeStarfield = () => {
            starCanvas.width = window.innerWidth;
            starCanvas.height = window.innerHeight;
            generateStars();
        };

        const drawStarfield = () => {
            const gradient = starCtx.createLinearGradient(0, 0, 0, starCanvas.height);
            gradient.addColorStop(0, '#05070d');
            gradient.addColorStop(0.5, '#020408');
            gradient.addColorStop(1, '#000000');
            starCtx.fillStyle = gradient;
            starCtx.fillRect(0, 0, starCanvas.width, starCanvas.height);

            const nebulaRadial = starCtx.createRadialGradient(
                starCanvas.width * 0.8, starCanvas.height * 0.4, 10,
                starCanvas.width * 0.8, starCanvas.height * 0.4, starCanvas.width * 0.6
            );
            nebulaRadial.addColorStop(0, 'rgba(139, 92, 246, 0.06)');
            nebulaRadial.addColorStop(0.5, 'rgba(56, 189, 248, 0.03)');
            nebulaRadial.addColorStop(1, 'rgba(0,0,0,0)');
            starCtx.fillStyle = nebulaRadial;
            starCtx.fillRect(0, 0, starCanvas.width, starCanvas.height);

            starPoints.forEach(star => {
                star.opacity += star.twinkleSpeed;
                if (star.opacity > 1 || star.opacity < 0.1) {
                    star.twinkleSpeed = -star.twinkleSpeed;
                }

                const offsetX = mouseX * 25 * star.depth;
                const offsetY = (mouseY * 25 * star.depth) - (scrollY * 0.1 * star.depth);
                
                const finalX = (star.x + offsetX + starCanvas.width) % starCanvas.width;
                const finalY = (star.y + offsetY + starCanvas.height) % starCanvas.height;

                starCtx.beginPath();
                starCtx.arc(finalX, finalY, star.size, 0, Math.PI * 2);
                starCtx.fillStyle = `rgba(255, 255, 255, ${Math.max(0.1, Math.min(star.opacity, 1))})`;
                starCtx.fill();
            });

            if (!shootingStar && Math.random() < 0.003) {
                shootingStar = {
                    x: Math.random() * starCanvas.width * 0.6,
                    y: Math.random() * starCanvas.height * 0.4,
                    length: 60 + Math.random() * 80,
                    dx: 12 + Math.random() * 10,
                    dy: 4 + Math.random() * 6,
                    opacity: 1
                };
            }

            if (shootingStar) {
                starCtx.beginPath();
                const grad = starCtx.createLinearGradient(
                    shootingStar.x, shootingStar.y, 
                    shootingStar.x - shootingStar.dx, shootingStar.y - shootingStar.dy
                );
                grad.addColorStop(0, `rgba(56, 189, 248, ${shootingStar.opacity})`);
                grad.addColorStop(1, 'rgba(56, 189, 248, 0)');
                starCtx.strokeStyle = grad;
                starCtx.lineWidth = 1.5;
                starCtx.moveTo(shootingStar.x, shootingStar.y);
                starCtx.lineTo(shootingStar.x - shootingStar.dx, shootingStar.y - shootingStar.dy);
                starCtx.stroke();

                shootingStar.x += shootingStar.dx;
                shootingStar.y += shootingStar.dy;
                shootingStar.opacity -= 0.02;

                if (shootingStar.opacity <= 0) shootingStar = null;
            }
        };

        window.addEventListener('resize', resizeStarfield);
        resizeStarfield();

        // ==================== THREE.JS PIPELINE SETUP ====================
        const container = threeContainerRef.current;
        if (!container) return;

        let isDeviceReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        
        const width = container.clientWidth;
        const height = container.clientHeight;

        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
        camera.position.z = window.innerWidth < 768 ? 4.5 : 3.8;

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(width, height);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        container.appendChild(renderer.domElement);

        const worldGroup = new THREE.Group();
        scene.add(worldGroup);

        const earthGeo = new THREE.SphereGeometry(1.3, 64, 64);
        const earthMat = new THREE.ShaderMaterial({
            vertexShader: earthVertexShader,
            fragmentShader: earthFragmentShader,
        });
        const earthMesh = new THREE.Mesh(earthGeo, earthMat);
        worldGroup.add(earthMesh);

        const cloudGeo = new THREE.SphereGeometry(1.32, 64, 64);
        const cloudMat = new THREE.MeshStandardMaterial({
            color: 0xffffff,
            transparent: true,
            opacity: 0.35,
            blending: THREE.NormalBlending
        });
        const cloudMesh = new THREE.Mesh(cloudGeo, cloudMat);
        
        const canvasClouds = document.createElement('canvas');
        canvasClouds.width = 1024;
        canvasClouds.height = 512;
        const ctxClouds = canvasClouds.getContext('2d');
        if (ctxClouds) {
            ctxClouds.fillStyle = "rgba(0,0,0,0)";
            ctxClouds.fillRect(0, 0, 1024, 512);
            for (let i = 0; i < 50; i++) {
                ctxClouds.beginPath();
                ctxClouds.arc(Math.random() * 1024, Math.random() * 512, 30 + Math.random() * 80, 0, Math.PI * 2);
                ctxClouds.fillStyle = `rgba(255, 255, 255, ${0.1 + Math.random() * 0.35})`;
                ctxClouds.filter = 'blur(15px)';
                ctxClouds.fill();
            }
            cloudMat.alphaMap = new THREE.CanvasTexture(canvasClouds);
            cloudMat.alphaMap.needsUpdate = true;
        }
        worldGroup.add(cloudMesh);

        const atmosGeo = new THREE.SphereGeometry(1.48, 32, 32);
        const atmosVertex = `
            varying vec3 vNormal;
            void main() {
                vNormal = normalize(normalMatrix * normal);
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `;
        const atmosFragment = `
            varying vec3 vNormal;
            void main() {
                float intensity = pow(0.68 - dot(vNormal, vec3(0, 0, 1.0)), 2.8);
                gl_FragColor = vec4(0.22, 0.74, 0.97, 1.0) * intensity * 0.95;
            }
        `;
        const atmosMat = new THREE.ShaderMaterial({
            vertexShader: atmosVertex,
            fragmentShader: atmosFragment,
            blending: THREE.AdditiveBlending,
            side: THREE.BackSide,
            transparent: true
        });
        const atmosphereMesh = new THREE.Mesh(atmosGeo, atmosMat);
        worldGroup.add(atmosphereMesh);

        worldGroup.rotation.y = -2.1;
        worldGroup.rotation.x = 0.28;

        const resizeThree = () => {
            const w = container.clientWidth;
            const h = container.clientHeight;
            camera.aspect = w / h;
            camera.position.z = window.innerWidth < 768 ? 4.5 : 3.8;
            camera.updateProjectionMatrix();
            renderer.setSize(w, h);
        };
        window.addEventListener('resize', resizeThree);

        let isDragging = false;
        let previousMousePosition = { x: 0, y: 0 };

        const onMouseDown = (e: MouseEvent) => {
            isDragging = true;
            previousMousePosition = { x: e.clientX, y: e.clientY };
        };
        const onMouseMove = (e: MouseEvent) => {
            if (!isDragging) return;
            const deltaMove = {
                x: e.clientX - previousMousePosition.x,
                y: e.clientY - previousMousePosition.y
            };

            worldGroup.rotation.y += deltaMove.x * 0.005;
            worldGroup.rotation.x += deltaMove.y * 0.005;

            previousMousePosition = { x: e.clientX, y: e.clientY };
        };
        const onMouseUp = () => {
            isDragging = false;
        };

        container.addEventListener('mousedown', onMouseDown);
        container.addEventListener('mousemove', onMouseMove);
        window.addEventListener('mouseup', onMouseUp);

        const onTouchStart = (e: TouchEvent) => {
            if (e.touches.length === 1) {
                isDragging = true;
                previousMousePosition = { x: e.touches[0].clientX, y: e.touches[0].clientY };
            }
        };
        const onTouchMove = (e: TouchEvent) => {
            if (!isDragging || e.touches.length !== 1) return;
            const deltaMove = {
                x: e.touches[0].clientX - previousMousePosition.x,
                y: e.touches[0].clientY - previousMousePosition.y
            };

            worldGroup.rotation.y += deltaMove.x * 0.008;
            worldGroup.rotation.x += deltaMove.y * 0.008;

            previousMousePosition = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        };
        const onTouchEnd = () => {
            isDragging = false;
        };

        container.addEventListener('touchstart', onTouchStart, { passive: true });
        container.addEventListener('touchmove', onTouchMove, { passive: true });
        container.addEventListener('touchend', onTouchEnd);

        // ==================== LOOP RENDER STEP ====================
        const clock = new THREE.Clock();
        let animationFrameId: number;

        const renderStep = () => {
            animationFrameId = requestAnimationFrame(renderStep);

            const elapsed = clock.getDelta();
            
            mouseX += (targetMouseX - mouseX) * 0.08;
            mouseY += (targetMouseY - mouseY) * 0.08;

            earthMesh.rotation.y += elapsed * 0.035;
            cloudMesh.rotation.y += elapsed * 0.045; 

            if (!isDragging) {
                worldGroup.rotation.y += mouseX * 0.002;
                worldGroup.rotation.x += mouseY * 0.001;
            }

            const maxScrollOffset = 400;
            const currentScrollRatio = Math.min(scrollY / maxScrollOffset, 1);
            
            if (window.innerWidth >= 1024) {
                worldGroup.position.x = currentScrollRatio * 0.8;
                worldGroup.position.y = -currentScrollRatio * 0.2;
                worldGroup.scale.setScalar(1 - currentScrollRatio * 0.15);
            } else {
                worldGroup.position.y = currentScrollRatio * 0.2;
                worldGroup.scale.setScalar(0.7 - currentScrollRatio * 0.1);
            }

            drawStarfield();

            const textBlock = textBlockRef.current;
            if (textBlock) {
                textBlock.style.opacity = (1 - currentScrollRatio * 1.2).toString();
                textBlock.style.transform = `translateY(${scrollY * 0.35}px)`;
            }

            renderer.render(scene, camera);
        };

        if (isDeviceReducedMotion) {
            drawStarfield();
            renderer.render(scene, camera);
        } else {
            renderStep();
        }

        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('scroll', handleScroll);
            window.removeEventListener('deviceorientation', handleDeviceOrientation as any);
            window.removeEventListener('resize', resizeStarfield);
            window.removeEventListener('resize', resizeThree);
            window.removeEventListener('mouseup', onMouseUp);
            container.removeEventListener('mousedown', onMouseDown);
            container.removeEventListener('mousemove', onMouseMove);
            container.removeEventListener('touchstart', onTouchStart);
            container.removeEventListener('touchmove', onTouchMove);
            container.removeEventListener('touchend', onTouchEnd);
            cancelAnimationFrame(animationFrameId);
            container.removeChild(renderer.domElement);
            renderer.dispose();
            scene.clear();
        };
    }, []);

    const scrollToContact = () => {
        document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
    }

    const scrollToPortfolio = () => {
        document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth' });
    }

    return (
        <section id="hero" className="relative min-h-screen flex items-center justify-center px-6 md:px-12 lg:px-24 pt-24 pb-16 overflow-hidden bg-[#05070d]">
            <style>{`
                .glow-button::before {
                    content: '';
                    position: absolute;
                    inset: -2px;
                    background: linear-gradient(90deg, #38bdf8, #8b5cf6, #38bdf8);
                    background-size: 200% 100%;
                    border-radius: 14px;
                    z-index: -1;
                    opacity: 0;
                    transition: opacity 0.4s ease;
                    animation: moveGradient 4s linear infinite;
                }
                .glow-button:hover::before {
                    opacity: 1;
                }
                @keyframes moveGradient {
                    0% { background-position: 0% 50%; }
                    100% { background-position: 200% 50%; }
                }
            `}</style>
            <canvas ref={starCanvasRef} id="space-background" className="absolute inset-0 w-full h-full pointer-events-none z-0"></canvas>
            <div className="max-w-[90rem] mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
                
                <div ref={textBlockRef} className="lg:col-span-7 flex flex-col items-start text-left z-20 pointer-events-auto" id="hero-text-block">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.1 }}
                        className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-slate-900/80 border border-sky-500/30 text-[#38bdf8] text-xs md:text-sm font-medium tracking-wide mb-6 backdrop-blur-md shadow-[0_0_15px_rgba(56,189,248,0.1)]"
                    >
                        <span className="w-1.5 h-1.5 rounded-full bg-[#38bdf8] animate-pulse"></span>
                        <span>Next-Gen Web Development & Digital Marketing</span>
                    </motion.div>

                    <motion.h1 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                        className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold leading-[1.1] tracking-tight mb-6 text-white"
                    >
                        Build a Digital <br className="hidden sm:inline" />
                        Presence That Feels <br />
                        <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#38bdf8] via-[#8b5cf6] to-white">
                            Out of This World
                        </span>
                    </motion.h1>

                    <motion.p 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.3 }}
                        className="text-base sm:text-lg md:text-xl text-[#b6c2d1] font-light leading-relaxed max-w-xl mb-8"
                    >
                        We create fast, premium, responsive websites, SEO systems, and digital marketing experiences designed to attract, engage, and convert.
                    </motion.p>

                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.4 }}
                        className="flex flex-wrap gap-4 w-full sm:w-auto"
                    >
                        <button onClick={scrollToContact} className="glow-button relative px-8 py-4 rounded-xl font-semibold bg-gradient-to-r from-[#38bdf8] to-[#8b5cf6] text-white shadow-[0_0_25px_rgba(56,189,248,0.25)] hover:shadow-[0_0_35px_rgba(56,189,248,0.45)] transition-all duration-300 flex items-center space-x-2 overflow-hidden w-full sm:w-auto justify-center">
                            <span>Start Your Project</span>
                            <ArrowRight className="w-4 h-4 ml-1" />
                        </button>
                        <button onClick={scrollToPortfolio} className="px-8 py-4 rounded-xl font-semibold bg-white/5 border border-white/10 hover:bg-white/10 transition-all duration-300 w-full sm:w-auto text-center backdrop-blur-md text-white">
                            View Our Work
                        </button>
                    </motion.div>
                </div>

                <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 1.5 }}
                    className="lg:col-span-5 h-[400px] md:h-[600px] w-full relative flex items-center justify-center z-10" id="canvas-wrapper"
                >
                    <div className="absolute w-80 h-80 rounded-full bg-[#8b5cf6]/20 blur-[100px] pointer-events-none mix-blend-screen animate-pulse"></div>
                    <div className="absolute w-72 h-72 rounded-full bg-[#38bdf8]/20 blur-[80px] pointer-events-none mix-blend-screen"></div>
                    
                    <div ref={threeContainerRef} id="three-container" className="w-full h-full absolute inset-0 cursor-grab active:cursor-grabbing"></div>
                </motion.div>

            </div>

            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center pointer-events-none">
                <span className="text-xs tracking-widest text-[#b6c2d1] mb-2 uppercase opacity-60">Deploy Orbit</span>
                <div className="w-6 h-10 rounded-full border border-white/20 p-1 flex justify-center">
                    <div className="w-1.5 h-3 rounded-full bg-[#38bdf8] animate-bounce"></div>
                </div>
            </div>
        </section>
    );
};
