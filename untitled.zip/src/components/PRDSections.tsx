import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check, Code, LayoutDashboard, Search, Megaphone, TrendingUp, Users, Target, Rocket, LayoutTemplate, Briefcase, ChevronRight, Smartphone, Zap, SearchCode, PenTool, LayoutGrid, ChevronDown } from 'lucide-react';
import { Reveal } from '../components1';

import { DashboardPreviewVisual, MarketingDashboardVisual, AnimatedServiceIcon } from './AnimatedVisuals';

export const WebDevBanner = () => {
  return (
    <section className="py-24 relative overflow-hidden bg-[var(--bg-main)] border-y border-[var(--border-soft)]">
      <div className="max-w-[90rem] mx-auto px-4 lg:px-8 relative z-10 grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[var(--primary)]/10 border border-[var(--primary)]/20 rounded-full mb-6">
            <span className="text-xs font-bold text-[var(--primary)] uppercase tracking-widest">Premium Web Development</span>
          </div>
          <h2 className="clamp-h2 font-black text-[var(--text-main)] mb-6 leading-tight">High-Performance Websites Built for Real Business Growth</h2>
          <p className="text-lg text-[var(--text-muted)] font-medium mb-8">
            We don't just write code; we design digital experiences. Fast, responsive, and SEO-optimized web solutions tailored to elevate your brand.
          </p>
          <div className="flex gap-4">
            <a href="#contact" className="btn-primary px-8 py-4">Discuss Your Project</a>
          </div>
        </div>
        <div className="relative group">
          <DashboardPreviewVisual />
        </div>
      </div>
    </section>
  );
};

export const WebDevServices = () => {
    const services = [
        { icon: <LayoutDashboard size={24}/>, title: "Website Development", desc: "Professional, scalable, and easy-to-manage websites built to help your business grow online." },
        { icon: <SearchCode size={24}/>, title: "E-commerce Websites", desc: "Clean and secure online stores designed to give your customers a great shopping experience." },
        { icon: <LayoutTemplate size={24}/>, title: "Landing Pages", desc: "Single-page designs focused entirely on getting you more leads and running better ad campaigns." },
        { icon: <PenTool size={24}/>, title: "Branding & UI/UX", desc: "User-friendly interfaces and clean designs that make your business look trustworthy." },
        { icon: <Zap size={24}/>, title: "Speed Optimization", desc: "Fast-loading pages that keep visitors on your site and help improve your search rankings." },
        { icon: <LayoutGrid size={24}/>, title: "SEO-Ready Structure", desc: "Websites built with the right foundation so search engines can easily find and rank you." },
        { icon: <Smartphone size={24}/>, title: "Business Automation", desc: "Custom web solutions that connect to your business processes and save you time." },
        { icon: <Code size={24}/>, title: "Website Maintenance", desc: "Reliable technical support, security updates, and regular backups so you do not have to worry." }
    ];

    return (
        <section className="py-24 bg-[var(--bg-card)]">
            <div className="max-w-[90rem] mx-auto px-4 lg:px-8">
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {services.map((s, i) => (
                        <div key={i} className="bg-[var(--bg-surface)] p-8 rounded-2xl border border-[var(--border-soft)] hover:border-[var(--primary)]/50 smooth-transition hover:-translate-y-1 group flex flex-col h-full">
                            <AnimatedServiceIcon icon={s.icon} color="bg-[var(--primary)]/10 text-[var(--primary)]" />
                            <h3 className="font-bold text-lg text-[var(--text-main)] mb-3">{s.title}</h3>
                            <p className="text-sm text-[var(--text-muted)] font-medium leading-relaxed flex-grow">{s.desc}</p>
                            <a href="#contact" onClick={(e) => {
                                if (window.location.pathname === '/') {
                                    e.preventDefault();
                                    const select = document.getElementById('serviceInput') as HTMLSelectElement;
                                    if (select) {
                                      let optionFound = false;
                                      for(let j=0; j<select.options.length; j++) {
                                        if(select.options[j].value === s.title || select.options[j].value.includes(s.title)) {
                                          select.selectedIndex = j;
                                          optionFound = true;
                                          break;
                                        }
                                      }
                                      if(!optionFound) select.value = "Other";
                                    }
                                    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                                } else {
                                    window.location.href = '/#contact';
                                }
                            }} className="text-[var(--primary)] text-sm font-bold mt-6 inline-flex items-center hover:-translate-y-0.5 smooth-transition">
                                Learn More <ChevronRight size={16} className="ml-1" />
                            </a>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export const DigitalMarketingBanner = () => {
  return (
    <section className="py-24 relative overflow-hidden bg-[var(--bg-main)] border-y border-[var(--border-soft)]">
      <div className="max-w-[90rem] mx-auto px-4 lg:px-8 relative z-10 grid lg:grid-cols-2 gap-12 items-center">
        <div className="order-2 lg:order-1 relative group">
          <MarketingDashboardVisual />
        </div>
        <div className="order-1 lg:order-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[var(--primary)]/10 border border-[var(--primary)]/20 rounded-full mb-6">
            <span className="text-xs font-bold text-[var(--primary)] uppercase tracking-widest">Digital Marketing & Growth</span>
          </div>
          <h2 className="clamp-h2 font-black text-[var(--text-main)] mb-6 leading-tight">SEO, Meta Ads & Google Ads Designed to Bring Better Leads</h2>
          <p className="text-lg text-[var(--text-muted)] font-medium mb-8">
            Stop guessing with your marketing budget. We implement data-backed scaling strategies that target the right audience and convert traffic into revenue.
          </p>
          <div className="flex gap-4">
            <a href="#contact" className="btn-primary px-8 py-4">Get a Free Audit</a>
          </div>
        </div>
      </div>
    </section>
  );
};

export const DigitalMarketingServices = () => {
    const services = [
        { icon: <Search size={24}/>, title: "SEO Optimization", desc: "Technical and on-page strategies to help your website rank better organically on Google." },
        { icon: <Target size={24}/>, title: "Meta Ads Management", desc: "Targeted Facebook and Instagram campaigns designed to generate high-quality leads for your business." },
        { icon: <Briefcase size={24}/>, title: "Google Ads", desc: "Capture search traffic directly with optimized Pay-Per-Click campaigns that make sense for your budget." },
        { icon: <Users size={24}/>, title: "Lead Generation", desc: "End-to-end lead generation systems combining good landing pages with the right traffic." },
        { icon: <TrendingUp size={24}/>, title: "Retargeting Campaigns", desc: "Bring back previous visitors and give them another reason to choose your services." },
        { icon: <Rocket size={24}/>, title: "Conversion Tracking", desc: "Clear setup of analytics so you know exactly which marketing efforts are working." },
        { icon: <PenTool size={24}/>, title: "Content Strategy", desc: "Helpful, SEO-focused content that answers customer questions and builds your online authority." },
        { icon: <LayoutDashboard size={24}/>, title: "Performance Reporting", desc: "Transparent, easy-to-understand reports showing how your campaigns are doing each month." }
    ];

    return (
        <section className="py-24 bg-[var(--bg-card)]">
            <div className="max-w-[90rem] mx-auto px-4 lg:px-8">
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {services.map((s, i) => (
                        <div key={i} className="bg-[var(--bg-surface)] p-8 rounded-2xl border border-[var(--border-soft)] hover:border-[var(--primary)]/50 smooth-transition hover:-translate-y-1 group flex flex-col h-full">
                            <AnimatedServiceIcon icon={s.icon} color="bg-[var(--primary)]/10 text-[var(--primary)]" />
                            <h3 className="font-bold text-lg text-[var(--text-main)] mb-3">{s.title}</h3>
                            <p className="text-sm text-[var(--text-muted)] font-medium leading-relaxed flex-grow">{s.desc}</p>
                            <a href="#contact" onClick={(e) => {
                                if (window.location.pathname === '/') {
                                    e.preventDefault();
                                    const select = document.getElementById('serviceInput') as HTMLSelectElement;
                                    if (select) {
                                      let optionFound = false;
                                      for(let j=0; j<select.options.length; j++) {
                                        if(select.options[j].value === s.title || select.options[j].value.includes(s.title)) {
                                          select.selectedIndex = j;
                                          optionFound = true;
                                          break;
                                        }
                                      }
                                      if(!optionFound) select.value = "Other";
                                    }
                                    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                                } else {
                                    window.location.href = '/#contact';
                                }
                            }} className="text-[var(--primary)] text-sm font-bold mt-6 inline-flex items-center hover:-translate-y-0.5 smooth-transition">
                                Learn More <ChevronRight size={16} className="ml-1" />
                            </a>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export const WhyChooseDezo = () => {
   const details = [
       { title: "Affordable Premium Quality", desc: "Get agency-level design and scalable infrastructure without the typical high agency markup. Professionalism accessible to all." },
       { title: "Mobile-First Design", desc: "Over 80% of specific user traffic is mobile. We design for the smallest screen first to ensure perfect functionality everywhere." },
       { title: "Fast Loading Frameworks", desc: "Slow websites lose customers. We engineer lightweight, optimized platforms that load almost instantly on any connection." },
       { title: "Conversion-Focused", desc: "Every button placement, color choice, and headline is structured psychologically to turn a visitor into a lead." },
       { title: "SEO-Ready Architecture", desc: "We don't just build sites; we build them the way Google wants to read them, ensuring a strong foundation for future ranking." },
       { title: "Human Communication", desc: "No jargon, no runarounds. Direct, transparent human communication focusing purely on your business objectives." }
   ];

   return (
       <section className="py-24 bg-[var(--bg-main)] border-y border-[var(--border-soft)]">
            <div className="max-w-[90rem] mx-auto px-4 lg:px-8">
                <div className="text-center mb-16">
                    <h2 className="clamp-h2 font-black text-[var(--text-main)] mb-4">Why Choose DEZO?</h2>
                    <p className="text-lg text-[var(--text-muted)] font-medium">We deliver what matters: speed, trust, and conversions.</p>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {details.map((d, i) => (
                        <div key={i} className="flex gap-4 items-start">
                            <div className="w-8 h-8 rounded-full bg-[var(--primary)]/20 flex flex-shrink-0 items-center justify-center text-[var(--primary)] mt-1">
                                <Check size={16}/>
                            </div>
                            <div>
                                <h4 className="text-lg font-bold text-[var(--text-main)] mb-2">{d.title}</h4>
                                <p className="text-sm text-[var(--text-muted)] font-medium leading-relaxed">{d.desc}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
       </section>
   )
}

export const ProcessSectionPRD = () => {
    const steps = [
        { num: '01', title: 'Requirement Discussion', desc: 'Understanding your business model, goals, target audience, and precise digital requirements.' },
        { num: '02', title: 'Strategy & Structure', desc: 'Mapping out the user journey, SEO strategy, and overall architectural framework.' },
        { num: '03', title: 'Design', desc: 'Creating premium, conversion-focused visual interfaces tailored to your brand identity.' },
        { num: '04', title: 'Development', desc: 'Engineering the frontend and backend with clean, fast, and scalable code.' },
        { num: '05', title: 'Testing', desc: 'Rigorous multi-device testing for speed, responsiveness, and flawless execution.' },
        { num: '06', title: 'Launch', desc: 'Deploying the final product to a live production environment with zero downtime.' },
        { num: '07', title: 'Growth Support', desc: 'Ongoing maintenance, analytics tracking, and digital marketing strategies to scale.' }
    ];

    return (
        <section className="py-24 bg-[var(--bg-card)]">
            <div className="max-w-[90rem] mx-auto px-4 lg:px-8">
                <div className="text-center mb-16">
                    <h2 className="clamp-h2 font-black text-[var(--text-main)] mb-4">Our Methodology</h2>
                    <p className="text-lg text-[var(--text-muted)] font-medium">A structured, transparent 7-step process to digital excellence.</p>
                </div>
                
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 relative">
                    {steps.map((step, i) => (
                        <div key={i} className="glass-card p-6 rounded-2xl border border-[var(--border-soft)] hover:border-[var(--primary)]/50 smooth-transition relative group">
                            <div className="text-4xl font-black text-[var(--primary)] opacity-20 absolute top-4 right-4 z-0">{step.num}</div>
                            <h3 className="font-bold text-lg text-[var(--text-main)] mb-3 relative z-10">{step.title}</h3>
                            <p className="text-sm text-[var(--text-muted)] font-medium relative z-10">{step.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}

export const StatsSection = () => {
    return (
        <section className="py-20 bg-[var(--bg-main)] border-[var(--border-soft)] relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[var(--primary)]/5 to-transparent pointer-events-none"></div>
            <div className="max-w-[90rem] mx-auto px-4 lg:px-8 relative z-10">
                <div className="glass-card rounded-[2rem] border border-[var(--border-soft)] p-8 md:p-12 grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-x divide-[var(--border-soft)]">
                    <div>
                        <p className="text-3xl md:text-5xl font-black text-[var(--text-main)] mb-2 drop-shadow-sm">100<span className="text-[var(--primary)]">+</span></p>
                        <p className="text-xs md:text-sm font-bold uppercase tracking-widest text-[var(--text-muted)]">Projects Delivered</p>
                    </div>
                    <div>
                        <p className="text-3xl md:text-5xl font-black text-[var(--text-main)] mb-2 drop-shadow-sm">50<span className="text-[var(--primary)]">+</span></p>
                        <p className="text-xs md:text-sm font-bold uppercase tracking-widest text-[var(--text-muted)]">Happy Clients</p>
                    </div>
                    <div>
                        <p className="text-3xl md:text-5xl font-black text-[var(--text-main)] mb-2 drop-shadow-sm">99<span className="text-[var(--primary)]">%</span></p>
                        <p className="text-xs md:text-sm font-bold uppercase tracking-widest text-[var(--text-muted)]">Uptime Delivery</p>
                    </div>
                    <div>
                        <p className="text-3xl md:text-5xl font-black text-[var(--text-main)] mb-2 drop-shadow-sm">24<span className="text-[var(--primary)]">/7</span></p>
                        <p className="text-xs md:text-sm font-bold uppercase tracking-widest text-[var(--text-muted)]">Growth Support</p>
                    </div>
                </div>
            </div>
        </section>
    )
}

export const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Rajnish Kumar",
      role: "Founder, Real Estate Agency",
      text: "DEZO delivered a fantastic real estate platform for us. The load speed is incredible, and the design is extremely professional. We've seen a noticeable increase in inquiries since launch.",
      rating: 5
    },
    {
      name: "Priyanka Sahoo",
      role: "E-Commerce Store Owner",
      text: "I was struggling with sales on my old website. The new e-commerce store built by DEZO is clean, fast, and easy to use. My customers love it, and checkouts are much smoother.",
      rating: 5
    },
    {
      name: "Sanjay Dash",
      role: "Local Business Owner",
      text: "Transparency and quality are hard to find, but Tarik and his team at DEZO provided both. They handled our website and Meta Ads, and we saw a great return on investment within the first few weeks.",
      rating: 5
    }
  ];

  return (
    <section className="py-24 bg-[var(--bg-surface)] border-[var(--border-soft)] relative overflow-hidden">
      <div className="max-w-[90rem] mx-auto px-4 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="clamp-h2 font-black text-[var(--text-main)] mb-4 tracking-tight">What Our Clients Say</h2>
          <p className="text-[var(--text-muted)] font-medium max-w-2xl mx-auto text-lg pt-2">
            We let our work and our clients' success speak for us.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t, idx) => (
            <div key={idx} className="bg-[var(--bg-card)] p-8 rounded-3xl border border-[var(--border-soft)] shadow-md hover:-translate-y-1 smooth-transition">
              <div className="flex gap-1 mb-4">
                {[...Array(t.rating)].map((_, i) => (
                  <svg key={i} className="w-5 h-5 text-[var(--accent)] drop-shadow-sm" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-[var(--text-secondary)] font-medium italic mb-6 leading-relaxed">
                "{t.text}"
              </p>
              <div>
                <h4 className="font-bold text-[var(--text-main)]">{t.name}</h4>
                <p className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)]">{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export const FaqSection = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const faqs = [
    { q: "How long does a website take?", a: "For a standard business website or landing page, we usually deliver within 1 to 2 weeks. Custom platforms, e-commerce stores, or complex websites may take 4 to 8 weeks depending on the features." },
    { q: "Do you provide SEO?", a: "Yes, every website we build includes foundational technical SEO to ensure Google can properly read it. We also offer dedicated monthly SEO services to help you rank higher for competitive industry keywords." },
    { q: "Can you redesign an old website?", a: "Absolutely. We specialize in taking outdated websites and modernizing them for better speed, mobile responsiveness, and higher conversion rates. We ensure your existing SEO value is preserved during the transition." },
    { q: "Do you manage Meta Ads?", a: "Yes, we run and manage targeted Facebook and Instagram (Meta) Ads. We don't just set up the campaigns; we design the ad creatives, write the copy, and engineer the landing pages to maximize your return on ad spend." },
    { q: "Is the website mobile-friendly?", a: "100%. Over 70% of web traffic comes from mobile devices, so we design with a 'mobile-first' approach. Your website will look perfect and load instantly on all smartphones and tablets." },
    { q: "Can it be hosted on Vercel or Netlify?", a: "Yes. Our modern React and Next.js applications are perfectly optimized for edge-hosting platforms like Vercel and Netlify, providing you with incredible load speeds and enterprise-grade security." },
    { q: "Do you provide maintenance?", a: "Yes, we offer ongoing support and maintenance packages. We handle updates, security patches, backups, and minor content changes so you can entirely focus on running your business." }
  ];

  return (
    <section id="faq" className="py-24 lg:py-32 section-dark overflow-hidden border-t border-[var(--border-soft)] relative">
      <div className="absolute inset-0 bg-[var(--bg-main)] pointer-events-none z-[-1]"></div>
      <div className="max-w-[50rem] mx-auto px-4 lg:px-8">
        <Reveal direction="up">
          <div className="text-center mb-16">
            <h2 className="clamp-h2 font-black text-[var(--text-main)] tracking-tight">Frequently Asked Questions</h2>
          </div>
        </Reveal>
        
        <div className="space-y-4">
          {faqs.map((faq, idx) => (
            <Reveal key={idx} delay={idx * 50} direction="up">
              <div className="border border-[var(--border-soft)] rounded-2xl bg-[var(--bg-card)] overflow-hidden smooth-transition hover:border-[var(--primary)]/50">
                <button 
                  className="w-full px-6 py-5 flex items-center justify-between font-bold text-left focus:outline-none"
                  onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                >
                  <span className="text-base text-[var(--text-main)] pr-8">{faq.q}</span>
                  <div className={`w-8 h-8 rounded-full bg-[var(--bg-surface)] flex items-center justify-center border border-[var(--border-soft)] shrink-0 text-[var(--text-main)] smooth-transition ${openIndex === idx ? 'bg-[var(--primary)] text-white border-[var(--primary)] transform rotate-180' : ''}`}>
                    <ChevronDown size={16} />
                  </div>
                </button>
                <div 
                  className={`px-6 smooth-transition overflow-hidden ${openIndex === idx ? 'max-h-96 pb-5 opacity-100' : 'max-h-0 opacity-0'}`}
                >
                  <p className="text-[var(--text-muted)] font-medium pb-2 text-sm leading-relaxed">{faq.a}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};
