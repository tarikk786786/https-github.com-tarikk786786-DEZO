import React from 'react';

export const ThemeStyles = () => (
  <style dangerouslySetInnerHTML={{__html: `
    :root {
      /* Theme System - DEZO Premium Light Theme */
      --bg-main: #FFFFFF;
      --bg-surface: #F7F9FC;
      --bg-secondary: #F7F9FC;
      --bg-card: #FFFFFF;
      
      --text-main: #0B1220;
      --text-primary: #0B1220;
      --text-secondary: #5B6472;
      --text-muted: #8A94A6;
      
      --accent-primary: #1D4ED8;
      --accent-primary-light: #0F2E8A;
      --accent-secondary: #F5B301;
      --accent-glow: rgba(29, 78, 216, 0.22);
      --highlight: #F5B301;
      --border-gold: rgba(245, 179, 1, 0.28);
      --gold-glow: rgba(245, 179, 1, 0.10);
      
      --whatsapp-green: #25D366;
      --success-green: #16A34A;
      --danger: #DC2626;

      --primary: #1D4ED8;
      --primary-dark: #0F2E8A;
      --accent: #F5B301;
      --accent-soft: #FFF4CC;
      
      --border-soft: #E5EAF2;
      --shadow-soft: 0 20px 50px rgba(15, 23, 42, 0.08);
      
      --gradient-main: linear-gradient(135deg, #1D4ED8 0%, #0F2E8A 100%);
      --gradient-dark: linear-gradient(180deg, #FFFFFF 0%, #F7F9FC 100%);

      --radius-sm: 0.5rem;
      --radius-md: 1rem;
      --radius-lg: 1.5rem;
      --radius-xl: 1.5rem; /* 24px */
      
      --section-padding: 6rem;
      --container-width: 1200px;
      
      /* Mapping variables for backward compatibility */
      --bg-nav: rgba(255, 255, 255, 0.95);
      --bg-dark: var(--bg-main);
      --bg-light: var(--bg-surface);
      --bg-white: var(--bg-surface);
      --text-dark: var(--text-primary);
      --text-light: var(--text-secondary);
      --border-light: var(--border-soft);
      --border-dark: var(--border-soft);
      --anim-speed: 0.3s;
      
      --line-height-body: 1.7;
      --hero-bg: var(--bg-main);
      
      --glass-blur: 12px;
    }

    body {
      min-height: 100vh;
      background: var(--bg-main);
      color: var(--text-main);
      line-height: var(--line-height-body);
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      overflow-x: hidden;
      font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      text-rendering: optimizeLegibility;
      background-attachment: fixed;
    }

    .hero {
      background: var(--bg-main);
    }

    .luxury-card, .glass-card {
      background: var(--bg-card) !important;
      border: 1px solid var(--border-soft) !important;
      box-shadow: var(--shadow-soft) !important;
      border-radius: 24px !important;
    }

    .section-dark {
      background: var(--bg-main);
      border-top: 1px solid var(--border-soft);
      border-bottom: 1px solid var(--border-soft);
      border-left: none;
      border-right: none;
    }

    /* Primary Button Style */
    .btn-primary {
      background: var(--gradient-main);
      color: #FFFFFF !important;
      border-radius: 999px;
      box-shadow: 0 12px 30px rgba(29, 78, 216, 0.22);
      transition: all 0.3s ease;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      border: none;
    }
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 16px 40px rgba(245, 179, 1, 0.28);
    }

    /* Rendering Optimizations */
    section {
      content-visibility: auto;
      contain-intrinsic-size: 1px 500px;
    }
    
    #home { content-visibility: visible; }

    /* Ultra-smooth transitions */
    .bg-main-dark, .bg-main-light,
    .text-main-dark, .text-main-light, .text-main-muted,
    .border-main-light, .border-main-dark {
      transition-property: background-color, color, border-color, box-shadow, transform, filter;
      transition-duration: 0.3s;
      transition-timing-function: cubic-bezier(0.16, 1, 0.3, 1);
    }

    .smooth-transition {
      transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    @media (max-width: 768px) {
      .heavy-animation,
      .particles,
      .canvas-bg,
      .desktop-only-animation {
        display: none !important;
      }
      .glass-card, .luxury-card, [class*="backdrop-blur"] {
        backdrop-filter: blur(8px) !important;
        -webkit-backdrop-filter: blur(8px) !important;
        background: var(--bg-card);
      }
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation-duration: 0.001ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.001ms !important;
        scroll-behavior: auto !important;
      }
    }

    .bg-main-dark { background-color: var(--bg-dark); }
    .bg-main-light { background-color: var(--bg-light); }
    
    .bg-gradient-main { background-image: var(--gradient-main); }
    .bg-gradient-dark { background-image: var(--gradient-dark); }
    .text-gradient-main {
      background-image: var(--gradient-main);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    
    .bg-white { background-color: var(--bg-card) !important; }
    
    .text-main-dark { color: var(--text-main); }
    .text-main-light { color: var(--text-main); }
    .text-main-muted { color: var(--text-secondary); }
    .border-main-light { border-color: var(--border-light); }
    .border-main-dark { border-color: var(--border-dark); }

    .smooth-transition { transition: all var(--anim-speed) cubic-bezier(0.22, 1, 0.36, 1); }
    
    @keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-5px); } }
    @keyframes float-delayed { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-8px); } }
    @keyframes shimmer { 0% { background-position: 200% center; } 100% { background-position: -200% center; } }
    @keyframes typing { from { width: 0 } to { width: 100% } }
    @keyframes blink-caret { from, to { border-color: transparent } 50% { border-color: var(--primary) } }
    @keyframes background-pan { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }

    .logo-animated {
      background: none;
    }

    .animate-float { animation: float 6s ease-in-out infinite; }
    .animate-float-delayed { animation: float-delayed 8s ease-in-out infinite 1s; }
    .animate-shimmer { background-size: 200% auto; animation: shimmer 4s linear infinite; }
    .animate-typing-code { overflow: hidden; white-space: nowrap; border-right: 2px solid var(--primary); animation: typing 3s steps(30, end) infinite alternate, blink-caret .75s step-end infinite; }
    .animate-gradient-text { background-size: 200% auto; animation: background-pan 6s linear infinite; }

    .hide-scrollbar::-webkit-scrollbar { display: none; }
    .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    html { scroll-behavior: smooth; }

    .clamp-h1 { font-size: clamp(2.2rem, 6vw, 4.5rem); line-height: 1.1; letter-spacing: -0.02em; font-weight: 800; word-break: break-word; color: var(--text-main); }
    .clamp-h2 { font-size: clamp(1.7rem, 4vw, 3rem); line-height: 1.2; letter-spacing: -0.01em; font-weight: 700; word-break: break-word; color: var(--text-main); }
    .clamp-p { font-size: clamp(1rem, 1.5vw, 1.125rem); line-height: 1.6; color: var(--text-secondary); }

    ::selection { background: var(--accent-secondary); color: #FFFFFF; }
    ::-moz-selection { background: var(--accent-secondary); color: #FFFFFF; }

    .hero-grid {
      background-size: 40px 40px;
      background-image: 
        linear-gradient(to right, rgba(29, 78, 216, 0.05) 1px, transparent 1px),
        linear-gradient(to bottom, rgba(29, 78, 216, 0.05) 1px, transparent 1px);
      mask-image: linear-gradient(to bottom, black 40%, transparent 100%);
      -webkit-mask-image: linear-gradient(to bottom, black 40%, transparent 100%);
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
    }
  `}} />
);
