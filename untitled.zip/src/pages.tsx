import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { ThemeStyles } from './ThemeStyles';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Globe, ChevronDown, Check, Zap, Code, TrendingUp, ArrowUpRight, X } from 'lucide-react';
import { portfolioData, categories } from './data';
import { toolsData, blogPosts, newsUpdates, faqData } from './extraData';
import { PricingSection, DigitalMarketingSection, ChallengeSection } from './components/PricingAndOffers';
import { PortfolioImageWithFallback } from './components/AnimatedVisuals';

const PageLayout = ({ title, h1, meta, children, schemaData }: any) => {
  const orgSchema = {
    "@context": "https://schema.org",
    "@type": "DigitalMarketingAgency",
    "name": "DEZO",
    "url": "https://dezo.in/",
    "logo": "https://dezo.in/logo.png",
    "description": "DEZO is a web development and digital marketing agency in India building fast websites, ecommerce stores, landing pages, SEO systems, Meta Ads and Google Ads campaigns for business growth.",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Bhubaneswar",
      "addressRegion": "Odisha",
      "postalCode": "751024",
      "addressCountry": "IN"
    },
    "telephone": "+919114411026",
    "email": "contact@dezo.in",
    "priceRange": "$$"
  };

  return (
    <div className="min-h-screen bg-[var(--bg-main)] text-[var(--text-main)] font-sans scroll-smooth pt-20 lg:pt-28">
      <ThemeStyles />
      <Helmet>
        <title>{title}</title>
        <meta name="title" content={title} />
        <meta name="description" content={meta} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={meta} />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={meta} />
        <link rel="canonical" href={`https://dezo.in${window.location.pathname}`} />
        <script type="application/ld+json">
          {JSON.stringify(orgSchema)}
        </script>
        {schemaData && (
          <script type="application/ld+json">
            {JSON.stringify(schemaData)}
          </script>
        )}
      </Helmet>
      <main className="max-w-[90rem] mx-auto px-4 lg:px-8 py-12 lg:py-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="clamp-h2 font-black text-main-light mb-6">{h1}</h1>
          <div className="prose prose-lg prose-slate max-w-none text-main-muted mb-12">
            {children}
          </div>
          <div className="mt-12 pt-12 border-t border-[var(--border-soft)]">
            <h3 className="text-xl font-bold mb-6 text-main-light">Explore Our Services</h3>
            <div className="flex flex-wrap gap-3">
              <Link to="/web-development-company-india" className="px-4 py-2 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] border border-[var(--border-soft)] rounded-full text-sm font-bold text-main-muted hover:text-brand-primary smooth-transition">Web Development</Link>
              <Link to="/website-development-bhubaneswar" className="px-4 py-2 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] border border-[var(--border-soft)] rounded-full text-sm font-bold text-main-muted hover:text-brand-primary smooth-transition">Web Dev in Bhubaneswar</Link>
              <Link to="/digital-marketing-agency-india" className="px-4 py-2 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] border border-[var(--border-soft)] rounded-full text-sm font-bold text-main-muted hover:text-brand-primary smooth-transition">Digital Marketing</Link>
              <Link to="/seo-services-india" className="px-4 py-2 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] border border-[var(--border-soft)] rounded-full text-sm font-bold text-main-muted hover:text-brand-primary smooth-transition">SEO Services</Link>
              <Link to="/meta-ads-agency-india" className="px-4 py-2 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] border border-[var(--border-soft)] rounded-full text-sm font-bold text-main-muted hover:text-brand-primary smooth-transition">Meta Ads</Link>
              <Link to="/google-ads-agency-india" className="px-4 py-2 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] border border-[var(--border-soft)] rounded-full text-sm font-bold text-main-muted hover:text-brand-primary smooth-transition">Google Ads</Link>
              <Link to="/ecommerce-website-development" className="px-4 py-2 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] border border-[var(--border-soft)] rounded-full text-sm font-bold text-main-muted hover:text-brand-primary smooth-transition">Ecommerce</Link>
              <Link to="/landing-page-design-services" className="px-4 py-2 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] border border-[var(--border-soft)] rounded-full text-sm font-bold text-main-muted hover:text-brand-primary smooth-transition">Landing Pages</Link>
            </div>
          </div>
          <div className="bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] border border-[var(--border-soft)] p-8 rounded-3xl mt-12 text-center shadow-sm">
            <h2 className="text-2xl font-black mb-4 text-main-light">Ready to Start Your Project?</h2>
            <p className="mb-6 font-medium">Get a free website audit or consultation for your digital growth strategy.</p>
            <Link to="/" onClick={() => {
              window.scrollTo(0,0);
              setTimeout(() => {
                const el = document.getElementById('contact');
                if(el) el.scrollIntoView({behavior:'smooth'});
              }, 300);
            }} className="btn-primary px-8 py-4">Get Free Website Audit</Link>
          </div>
        </div>
      </main>
    </div>
  );
};

export const WebDevPage = () => {
  const schema = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "Web Development Services",
      "provider": {
        "@type": "DigitalMarketingAgency",
        "name": "DEZO"
      },
      "areaServed": "India",
      "description": "DEZO creates premium, fast-loading, and mobile-friendly websites designed for maximum conversions."
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://dezo.in/"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "Web Development Company in India",
        "item": "https://dezo.in/web-development-company-india"
      }]
    }
  ];

  return (
  <PageLayout 
    title="Web Development Company in India - DEZO" 
    h1="Web Development Company in India" 
    meta="DEZO builds fast, modern and SEO-ready websites for businesses in India, including business websites, ecommerce stores, landing pages and custom web solutions."
    schemaData={schema}
  >
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Custom Business Website Development</h2>
    <p>As a leading web development company in India, DEZO creates premium, fast-loading, and mobile-friendly websites designed for maximum conversions. We focus on clean code, an excellent user experience, and strong technical SEO structures to ensure your brand stands out in the competitive market.</p>
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Our Web Development Services</h2>
    <ul className="list-disc pl-5 mt-4 space-y-2">
      <li>React and Next.js custom applications</li>
      <li>Responsive, mobile-first business websites</li>
      <li>High-performance ecommerce platforms</li>
      <li>Conversion-optimized landing pages</li>
      <li>Website redesign and performance improvements</li>
    </ul>
    <p className="mt-6">We don't just build websites; we build scalable digital systems tailored to your specific business requirements, integrated with modern analytics, and optimized for lead generation. Our development process guarantees premium quality, fast performance, transparent process, SEO-ready structure, and reliable support after delivery.</p>

    <div className="mt-12 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] p-8 rounded-3xl border border-[var(--border-soft)]">
      <h2 className="text-2xl font-bold text-main-light mb-6">Frequently Asked Questions</h2>
      <div className="space-y-6">
        <div>
          <h3 className="font-bold text-main-light text-lg">How long does it take to develop a custom website?</h3>
          <p className="mt-2 text-main-muted">A standard business website typically takes 2-4 weeks from design to launch, depending on the complexity and features required.</p>
        </div>
        <div>
          <h3 className="font-bold text-main-light text-lg">Are your websites mobile-friendly and SEO optimized?</h3>
          <p className="mt-2 text-main-muted">Yes, all our websites are built with a mobile-first approach and include technical SEO best practices out of the box to ensure high visibility on Google.</p>
        </div>
      </div>
    </div>
  </PageLayout>
  );
};

export const BbsrWebDevPage = () => {
  const schema = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "Website Development Bhubaneswar",
      "provider": {
        "@type": "LocalBusiness",
        "name": "DEZO"
      },
      "areaServed": "Bhubaneswar, Odisha",
      "description": "DEZO helps businesses in Bhubaneswar, Odisha build fast websites, improve Google visibility, and generate leads."
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://dezo.in/"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "Website Development Bhubaneswar",
        "item": "https://dezo.in/website-development-bhubaneswar"
      }]
    }
  ];

  return (
  <PageLayout 
    title="Website Development Company in Bhubaneswar - DEZO" 
    h1="Website Development Company in Bhubaneswar" 
    meta="DEZO provides website development in Bhubaneswar for businesses, startups and ecommerce brands looking for fast, mobile-friendly and SEO-ready websites."
    schemaData={schema}
  >
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Website Development & Digital Marketing Services in Bhubaneswar, Odisha</h2>
    <p>DEZO helps businesses in Bhubaneswar, Odisha and across India build fast websites, improve Google visibility, generate leads through SEO, and run Meta Ads and Google Ads campaigns. Known as a premier website development company in Bhubaneswar, our mission is to empower local businesses with world-class digital assets.</p>
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Leading Digital Marketing Agency in Bhubaneswar</h2>
    <p>Our deep understanding of the local market combined with global development standards makes us the ideal digital marketing agency in Bhubaneswar. We utilize modern technology to ensure that your website design in Odisha exceeds industry benchmarks and drives tangible business results.</p>
    
    <div className="mt-12 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] p-8 rounded-3xl border border-[var(--border-soft)]">
      <h2 className="text-2xl font-bold text-main-light mb-6">Frequently Asked Questions</h2>
      <div className="space-y-6">
        <div>
          <h3 className="font-bold text-main-light text-lg">Do you provide local SEO services in Bhubaneswar?</h3>
          <p className="mt-2 text-main-muted">Yes, our SEO strategies are highly localized. We help businesses rank on the first page of Google for targeted keywords specific to Bhubaneswar and Odisha.</p>
        </div>
        <div>
          <h3 className="font-bold text-main-light text-lg">Can I meet your team in person?</h3>
          <p className="mt-2 text-main-muted">Absolutely. If you run a business in Bhubaneswar, our team would be happy to schedule an in-person consultation to discuss your digital strategy.</p>
        </div>
      </div>
    </div>
  </PageLayout>
  );
};

export const DigitalMarketingPage = () => {
  const schema = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "Digital Marketing Services",
      "provider": {
        "@type": "DigitalMarketingAgency",
        "name": "DEZO"
      },
      "areaServed": "India",
      "description": "DEZO crafts tailored marketing funnels that target your ideal audience and guide them to conversion."
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://dezo.in/"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "Digital Marketing Agency India",
        "item": "https://dezo.in/digital-marketing-agency-india"
      }]
    }
  ];

  return (
  <PageLayout 
    title="Digital Marketing Agency in India - DEZO" 
    h1="Digital Marketing Agency in India" 
    meta="DEZO helps Indian businesses grow with SEO, Meta Ads, Google Ads, landing pages, tracking setup and conversion-focused digital marketing strategies."
    schemaData={schema}
  >
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Comprehensive Digital Marketing Strategies</h2>
    <p>In today's digital era, having a website is not enough. You need consistent, high-quality traffic. As a results-driven digital marketing agency in India, DEZO crafts tailored marketing funnels that target your ideal audience and guide them to conversion.</p>
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Our Approach</h2>
    <p>We analyze your business goals, audit your current digital footprint, and implement data-backed marketing campaigns. Our expertise spans across search engine optimization, pay-per-click advertising, social media management, and robust pixel tracking. We provide premium quality, fast performance, transparent process, SEO-ready structure, and reliable support.</p>

    <div className="mt-12 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] p-8 rounded-3xl border border-[var(--border-soft)]">
      <h2 className="text-2xl font-bold text-main-light mb-6">Frequently Asked Questions</h2>
      <div className="space-y-6">
        <div>
          <h3 className="font-bold text-main-light text-lg">What digital marketing services do you offer?</h3>
          <p className="mt-2 text-main-muted">We offer comprehensive 360-degree digital marketing services including SEO, Meta Ads management, Google Ads, content marketing, and conversion rate optimization.</p>
        </div>
        <div>
          <h3 className="font-bold text-main-light text-lg">How do you measure a successful campaign?</h3>
          <p className="mt-2 text-main-muted">We measure success by ROI/ROAS, cost per lead (CPL), and high-intent traffic metrics via advanced tracking with Google Tag Manager and GA4.</p>
        </div>
      </div>
    </div>
  </PageLayout>
  );
};

export const SeoServicesPage = () => {
  const schema = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "SEO Services",
      "provider": {
        "@type": "DigitalMarketingAgency",
        "name": "DEZO"
      },
      "areaServed": "India",
      "description": "DEZO provides data-driven SEO services in India targeting organic visibility and long-term brand authority."
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://dezo.in/"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "SEO Services India",
        "item": "https://dezo.in/seo-services-india"
      }]
    }
  ];

  return (
  <PageLayout 
    title="SEO Services in India - DEZO" 
    h1="SEO Services in India" 
    meta="DEZO provides SEO services in India including technical SEO, on-page SEO, local SEO, keyword optimization, content structure and website performance improvements."
    schemaData={schema}
  >
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Data-Driven SEO for Predictable Growth</h2>
    <p>Ranking on the first page of Google is crucial for long-term success. Our specialized SEO services in India are designed to improve your organic visibility, drive targeted traffic, and establish your brand as an authority.</p>
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">What We Optimize</h2>
    <p>We focus on all pillars of Search Engine Optimization: Technical SEO to ensure crawlability and fast page speeds; On-Page SEO for structured content and intelligent keyword placement; and Off-Page SEO to build high-quality backlinks and domain authority.</p>

    <div className="mt-12 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] p-8 rounded-3xl border border-[var(--border-soft)]">
      <h2 className="text-2xl font-bold text-main-light mb-6">Frequently Asked Questions</h2>
      <div className="space-y-6">
        <div>
          <h3 className="font-bold text-main-light text-lg">How long does it take to see SEO results?</h3>
          <p className="mt-2 text-main-muted">SEO is a medium-to-long-term strategy. You can typically expect to see noticeable improvements in rankings and traffic within 3 to 6 months.</p>
        </div>
        <div>
          <h3 className="font-bold text-main-light text-lg">Do you do local SEO for businesses in my city?</h3>
          <p className="mt-2 text-main-muted">Yes, our local SEO services help you dominate the local pack and map results for users searching near your business location.</p>
        </div>
      </div>
    </div>
  </PageLayout>
  );
};

export const MetaAdsPage = () => {
  const schema = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "Meta Ads Management",
      "provider": {
        "@type": "DigitalMarketingAgency",
        "name": "DEZO"
      },
      "areaServed": "India",
      "description": "DEZO designs, launches, and optimizes Facebook and Instagram ad campaigns that deliver measurable ROAS."
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://dezo.in/"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "Meta Ads Agency India",
        "item": "https://dezo.in/meta-ads-agency-india"
      }]
    }
  ];

  return (
  <PageLayout 
    title="Meta Ads Agency in India - DEZO" 
    h1="Meta Ads Agency in India" 
    meta="DEZO creates and manages Meta Ads campaigns for businesses in India with high-converting creatives, landing pages, tracking and performance optimization."
    schemaData={schema}
  >
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">High-ROI Paid Social Advertising</h2>
    <p>Social media advertising is one of the fastest ways to scale your business. As an expert Meta Ads agency in India, DEZO designs, launches, and optimizes Facebook and Instagram ad campaigns that deliver measurable return on ad spend (ROAS).</p>
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Our Campaign Framework</h2>
    <p>From audience segmentation and compelling ad creatives to rigorous A/B testing and pixel tracking setup, our methodology ensures that every dollar you spend is maximized for lead generation and ecommerce sales. Our process guarantees premium quality, transparent reporting, and continuous performance optimization.</p>

    <div className="mt-12 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] p-8 rounded-3xl border border-[var(--border-soft)]">
      <h2 className="text-2xl font-bold text-main-light mb-6">Frequently Asked Questions</h2>
      <div className="space-y-6">
        <div>
          <h3 className="font-bold text-main-light text-lg">Do you create the ad graphics and videos?</h3>
          <p className="mt-2 text-main-muted">Yes, our creative team designs high-converting statics, carousels, and video ad creatives optimized specifically for Meta placements.</p>
        </div>
        <div>
          <h3 className="font-bold text-main-light text-lg">What budget is recommended for Meta Ads?</h3>
          <p className="mt-2 text-main-muted">We recommend a starting ad spend of at least ₹30,000 to ₹50,000 per month so the algorithm has enough data to optimize efficiently.</p>
        </div>
      </div>
    </div>
  </PageLayout>
  );
};

export const GoogleAdsPage = () => {
  const schema = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "Google Ads Management",
      "provider": {
        "@type": "DigitalMarketingAgency",
        "name": "DEZO"
      },
      "areaServed": "India",
      "description": "DEZO manages highly targeted Google Ads campaigns designed to minimize wasted spend and maximize conversions."
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://dezo.in/"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "Google Ads Agency India",
        "item": "https://dezo.in/google-ads-agency-india"
      }]
    }
  ];

  return (
  <PageLayout 
    title="Google Ads Agency in India - DEZO" 
    h1="Google Ads Agency in India" 
    meta="DEZO provides Google Ads management in India to capture high-intent search traffic, generate leads, and drive sales through Search, Display, and Performance Max campaigns."
    schemaData={schema}
  >
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Capture High-Intent Search Traffic</h2>
    <p>When customers search for your services on Google, you need to be at the top. DEZO manages highly targeted Google Ads campaigns designed to minimize wasted spend and maximize conversions.</p>
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">PPC Management Expertise</h2>
    <p>We handle keyword research, negative keyword optimization, compelling ad copy, and landing page alignment to ensure high Quality Scores and lower costs per click. Whether it's Search, Shopping, or Performance Max, we build scalable ad systems with transparent process.</p>

    <div className="mt-12 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] p-8 rounded-3xl border border-[var(--border-soft)]">
      <h2 className="text-2xl font-bold text-main-light mb-6">Frequently Asked Questions</h2>
      <div className="space-y-6">
        <div>
          <h3 className="font-bold text-main-light text-lg">Do you guarantee leads with Google Ads?</h3>
          <p className="mt-2 text-main-muted">While we don't use weak terms like "ironclad guarantee", we do promise premium quality setups, rigorous optimization, and transparent reporting to maximize your ROAS and lead generation potential.</p>
        </div>
        <div>
          <h3 className="font-bold text-main-light text-lg">Why are my current Google Ads too expensive?</h3>
          <p className="mt-2 text-main-muted">High costs often come from bad keyword targeting, low Quality Scores, and poor landing page experiences. We audit and fix all of these to lower your Cost Per Acquisition.</p>
        </div>
      </div>
    </div>
  </PageLayout>
  );
};

export const EcommercePage = () => {
  const schema = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "Ecommerce Website Development",
      "provider": {
        "@type": "DigitalMarketingAgency",
        "name": "DEZO"
      },
      "areaServed": "India",
      "description": "DEZO provides robust ecommerce website development in India, crafting digital storefronts that turn visitors into loyal buyers."
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://dezo.in/"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "Ecommerce Website Development",
        "item": "https://dezo.in/ecommerce-website-development"
      }]
    }
  ];

  return (
  <PageLayout 
    title="Ecommerce Website Development in India - DEZO" 
    h1="Ecommerce Website Development" 
    meta="DEZO builds fast, scalable ecommerce websites in India designed to maximize sales, improve user experience, and rank on search engines."
    schemaData={schema}
  >
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Build an Online Store That Sells</h2>
    <p>Fast, secure, and user-friendly ecommerce stores are essential for modern retail. DEZO provides robust ecommerce website development in India, crafting digital storefronts that turn visitors into loyal buyers.</p>
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Features We Deliver</h2>
    <ul className="list-disc pl-5 mt-4 space-y-2">
      <li>Lightning-fast product load times and SEO-ready structure</li>
      <li>Secure payment gateway integrations (Razorpay, Stripe)</li>
      <li>Mobile-optimized checkout flows</li>
      <li>Inventory and order management systems</li>
      <li>Advanced analytics tracking setup</li>
    </ul>

    <div className="mt-12 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] p-8 rounded-3xl border border-[var(--border-soft)]">
      <h2 className="text-2xl font-bold text-main-light mb-6">Frequently Asked Questions</h2>
      <div className="space-y-6">
        <div>
          <h3 className="font-bold text-main-light text-lg">Which platform is best for my ecommerce store?</h3>
          <p className="mt-2 text-main-muted">Depending on your scale, we use Next.js for custom headless stores or robust platforms like Shopify and WooCommerce based on your specific operational needs and budget.</p>
        </div>
        <div>
          <h3 className="font-bold text-main-light text-lg">Do you help with payment gateway integration?</h3>
          <p className="mt-2 text-main-muted">Yes, we provide end-to-end setup including integrating Indian and International payment gateways securely.</p>
        </div>
      </div>
    </div>
  </PageLayout>
  );
};

export const LandingPagePage = () => {
  const schema = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "Landing Page Design",
      "provider": {
        "@type": "DigitalMarketingAgency",
        "name": "DEZO"
      },
      "areaServed": "India",
      "description": "DEZO designs high-converting landing pages for ad campaigns, product launches, and lead generation, focusing on speed and user psychology."
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://dezo.in/"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "Landing Page Design Services",
        "item": "https://dezo.in/landing-page-design-services"
      }]
    }
  ];

  return (
  <PageLayout 
    title="Landing Page Design Services - DEZO" 
    h1="Landing Page Design Services" 
    meta="DEZO designs high-converting landing pages for ad campaigns, product launches, and lead generation, focusing on speed and user psychology."
    schemaData={schema}
  >
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Convert Clicks Into Customers</h2>
    <p>Traffic is useless if it doesn't convert. Our landing page design services focus on user psychology, compelling copywriting, and frictionless UI/UX to ensure your ad campaigns yield the highest possible conversion rates.</p>
    <h2 className="text-2xl font-bold text-main-light mb-4 mt-8">Why Our Landing Pages Win</h2>
    <p>We build perfectly structured, blazing-fast landing pages with clear call-to-actions, social proof injection, and a distraction-free experience. Every element is tested and optimized for one goal: acquiring leads and generating sales. We ensure premium quality and fast performance across all devices.</p>

    <div className="mt-12 bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] p-8 rounded-3xl border border-[var(--border-soft)]">
      <h2 className="text-2xl font-bold text-main-light mb-6">Frequently Asked Questions</h2>
      <div className="space-y-6">
        <div>
          <h3 className="font-bold text-main-light text-lg">What makes a high-converting landing page?</h3>
          <p className="mt-2 text-main-muted">Fast load speeds, clear messaging, compelling headlines, strong social proof (reviews/testimonials), and a frictionless lead capture form or checkout process.</p>
        </div>
        <div>
          <h3 className="font-bold text-main-light text-lg">Do you integrate tracking tools on the landing page?</h3>
          <p className="mt-2 text-main-muted">Yes, every landing page comes with complete setup of Google Tag Manager, Google Analytics 4, Meta Pixel and any other required tracking systems so you never lose data.</p>
        </div>
      </div>
    </div>
  </PageLayout>
  );
};

export const ContactPage = () => {
  const schema = {
    "@context": "https://schema.org",
    "@type": "ContactPage",
    "name": "Contact DEZO",
    "description": "Contact DEZO for web development and digital marketing services."
  };
  return (
  <PageLayout 
    title="Contact DEZO - Web Development & Digital Marketing Agency" 
    h1="Contact DEZO" 
    meta="Get in touch with DEZO for custom web development, ecommerce solutions, SEO, Meta Ads and Google Ads services."
    schemaData={schema}
  >
    <div className="grid md:grid-cols-2 gap-8">
      <div>
        <h2 className="text-2xl font-bold text-main-light mb-4">Let's Discuss Your Digital Growth</h2>
        <p className="mb-6 text-main-muted">Whether you need a new website, a high-converting landing page, or a digital marketing strategy, our team is ready to help.</p>
        <div className="space-y-4">
          <p><strong>Phone:</strong> +91 91144 11026</p>
          <p><strong>Email:</strong> contact@dezo.in</p>
          <p><strong>Address:</strong> Phase 2, Patia, Bhubaneswar, Odisha 751024</p>
        </div>
      </div>
      <div>
        <div className="bg-[var(--bg-card)] backdrop-blur-[var(--glass-blur)] p-6 rounded-2xl border border-[var(--border-soft)] shadow-sm text-center">
          <h3 className="text-xl font-bold text-main-light mb-4">Schedule a Free Consultation</h3>
          <p className="mb-6 text-main-muted text-sm">We'll review your current digital presence and provide an actionable strategy.</p>
          <Link to="/" onClick={() => {
            window.scrollTo(0,0);
            setTimeout(() => {
              const el = document.getElementById('contact');
              if(el) el.scrollIntoView({behavior:'smooth'});
            }, 300);
          }} className="btn-primary px-8 py-4">Open Contact Form</Link>
        </div>
      </div>
    </div>
  </PageLayout>
  );
};

export const PortfolioPage = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const filteredPortfolio = portfolioData.filter(item => activeCategory === "All" || item.category === activeCategory);

  const schema = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": "DEZO Portfolio",
    "description": "View our full portfolio of custom websites, ecommerce stores, and digital marketing campaigns."
  };
  return (
  <PageLayout 
    title="Our Full Portfolio - DEZO" 
    h1="Our Complete Portfolio" 
    meta="Explore DEZO's full portfolio of custom websites, ecommerce stores, and digital marketing campaigns."
    schemaData={schema}
  >
    <p className="text-xl text-main-muted mb-8 leading-relaxed">We have partnered with 50+ businesses across multiple industries to deliver premium digital solutions. Explore our full gallery of work below.</p>
    
    <div className="flex flex-wrap gap-2 mb-10">
      {categories.map((cat, i) => (
        <button
          key={i}
          onClick={() => setActiveCategory(cat)}
          className={`px-5 py-2.5 rounded-full text-[11px] font-bold tracking-widest uppercase border smooth-transition active:scale-95 ${
            activeCategory === cat ? 'bg-white text-black border-white' : 'bg-[var(--gold-glow)] text-[var(--text-muted)] border-[var(--border-soft)] hover:border-white/30'
          }`}
        >
          {cat}
        </button>
      ))}
    </div>

    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
      {filteredPortfolio.map((project: any, i: number) => (
        <div key={i} className="bg-transparent h-full flex flex-col relative group">
          <div className="relative w-full aspect-video rounded-xl overflow-hidden mb-5 border border-[var(--border-soft)] bg-[var(--bg-surface)] group-hover:border-[var(--primary)]/30 smooth-transition">
            <PortfolioImageWithFallback title={project.title} src={`https://api.microlink.io/?url=${encodeURIComponent(project.url)}&screenshot=true&meta=false&embed=screenshot.url`} alt={project.title} />
            <div className="absolute top-4 left-4">
              <div className="text-[10px] font-bold text-[var(--text-main)] uppercase bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">{project.category}</div>
            </div>
          </div>
          <div className="relative z-10 flex flex-col flex-1 pb-4">
            <h4 className="text-xl font-bold text-[var(--text-main)] group-hover:text-[var(--primary)] mb-2 line-clamp-1 smooth-transition">{project.title}</h4>
            <div className="text-[13px] text-[var(--text-muted)] font-medium mb-4 line-clamp-2">Premium {project.category.toLowerCase()} web application built for speed and conversions.</div>
            <div className="mt-auto flex justify-between items-center gap-3">
              <a href={project.url} target="_blank" rel="noopener noreferrer" className="flex-1 py-3 text-center text-xs font-bold text-[var(--bg-main)] bg-[var(--text-main)] hover:bg-neutral-800 rounded-lg smooth-transition">Visit Site</a>
              <a href="#contact" onClick={(e) => {
                  window.location.href = `/#contact`;
              }} className="flex-1 py-3 text-center text-xs font-bold text-[#070707] bg-[var(--primary)] hover:bg-[var(--accent)] rounded-lg smooth-transition">Get Similar</a>
            </div>
          </div>
        </div>
      ))}
    </div>
  </PageLayout>
  );
};

export const BlogPage = () => {
  const [search, setSearch] = useState("");
  const [selectedPost, setSelectedPost] = useState<any>(null);
  const filteredBlogs = blogPosts.filter(b => b.title.toLowerCase().includes(search.toLowerCase()) || b.category.toLowerCase().includes(search.toLowerCase()));

  return (
    <PageLayout 
      title="Digital Growth Blog - DEZO" 
      h1="Insights & Strategies for Digital Growth" 
      meta="Read DEZO's blog for expert insights on web development, SEO, Meta Ads, Google Ads, and strategies to grow your business online."
    >
      <div className="mb-10 relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" size={18} />
        <input type="text" placeholder="Search articles..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full bg-[var(--bg-card)] border border-[var(--border-soft)] rounded-full py-4 pl-12 pr-6 text-sm text-[var(--text-main)] focus:outline-none focus:border-[var(--primary)] smooth-transition" />
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {filteredBlogs.map((post) => (
          <motion.div 
            key={post.id} 
            whileHover={{ y: -5 }}
            onClick={() => setSelectedPost(post)}
            className="bg-[var(--bg-card)] p-8 rounded-3xl border border-[var(--border-soft)] shadow-sm hover:border-[var(--primary)]/50 hover:shadow-xl smooth-transition cursor-pointer flex flex-col group"
          >
            <div className="flex justify-between items-center mb-4 text-xs font-bold uppercase tracking-widest text-[var(--text-muted)]">
              <span className="text-[var(--primary)]">{post.category}</span>
              <span>{post.date}</span>
            </div>
            <h3 className="text-2xl font-black text-[var(--text-main)] mb-4 leading-tight group-hover:text-[var(--primary)] smooth-transition">{post.title}</h3>
            <p className="text-[var(--text-muted)] font-medium mb-8 flex-1">{post.excerpt}</p>
            <span className="text-sm font-bold text-[var(--primary)] flex items-center gap-2 group-hover:gap-3 smooth-transition">Read Full Article <ArrowUpRight size={16}/></span>
          </motion.div>
        ))}
      </div>

      {selectedPost && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setSelectedPost(null)}>
          <div className="bg-[var(--bg-card)] p-8 md:p-12 rounded-3xl w-full max-w-2xl shadow-2xl relative" onClick={e => e.stopPropagation()}>
            <button onClick={() => setSelectedPost(null)} className="absolute top-4 right-4 w-10 h-10 bg-[var(--bg-soft)] rounded-full flex items-center justify-center text-[var(--text-main)] hover:bg-[var(--primary)]/10 hover:text-[var(--primary)] smooth-transition">
              <X size={20} />
            </button>
            <span className="text-xs font-bold text-[var(--primary)] uppercase tracking-widest block mb-4">{selectedPost.category} • {selectedPost.date}</span>
            <h2 className="text-3xl font-black text-[var(--text-main)] mb-6 leading-tight">{selectedPost.title}</h2>
            <div className="w-20 h-1 bg-[var(--primary)] mb-8 rounded-full"></div>
            <p className="text-[var(--text-main)] font-medium leading-relaxed mb-6">
              {selectedPost.excerpt}
            </p>
            <p className="text-[var(--text-muted)] leading-relaxed mb-8">
              This full article is currently being updated by our editorial team to reflect the latest strategies. Please sign up for our newsletter to get notified when the full in-depth guide is published.
            </p>
            <a href="#contact" onClick={(e) => {
                  window.location.href = `/#contact`;
              }} className="btn-primary px-8 py-4 w-full sm:w-auto inline-block text-center">
              Get Digital Marketing Audit
            </a>
          </div>
        </div>
      )}
    </PageLayout>
  );
};

export const ServicesPage = () => (
  <PageLayout title="All Services - DEZO" h1="Our Full Digital Services" meta="Complete list of services by DEZO including Web Dev, SEO, Marketing, Automation and Maintenance.">
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
      {[
        { title: "Web Development", desc: "React, Next.js, full-stack scalable platforms.", link: "/web-development-company-india" },
        { title: "SEO Strategy", desc: "Technical, On-Page, Off-Page search dominance.", link: "/seo-services-india" },
        { title: "Digital Marketing", desc: "End-to-end data-driven digital growth.", link: "/digital-marketing-agency-india" },
        { title: "Meta & Google Ads", desc: "High-ROI paid social and search campaigns.", link: "/meta-ads-agency-india" },
        { title: "Landing Pages", desc: "Conversion-optimized high-speed standalone pages.", link: "/landing-page-design-services" },
        { title: "Ecommerce Stores", desc: "Scalable online stores built to sell.", link: "/ecommerce-website-development" },
        { title: "Website Maintenance", desc: "Security, backups, hosting, and constant uptime.", link: "/contact" },
        { title: "UI/UX Design", desc: "Premium human-first digital experiences.", link: "/portfolio" }
      ].map((srv, idx) => (
        <div key={idx} className="bg-[var(--bg-card)] p-6 rounded-2xl border border-[var(--border-soft)] flex flex-col hover:border-[var(--primary)]/50 smooth-transition">
          <h3 className="text-xl font-bold text-main-light mb-2">{srv.title}</h3>
          <p className="text-sm text-main-muted mb-4 flex-1">{srv.desc}</p>
          <Link to={srv.link} className="text-xs font-bold text-[var(--primary)] uppercase tracking-widest flex items-center gap-1 hover:gap-2 smooth-transition">Explore <ArrowUpRight size={14}/></Link>
        </div>
      ))}
    </div>
    <div className="-mx-4 sm:-mx-8">
      <DigitalMarketingSection />
    </div>
  </PageLayout>
);

export const ToolsPage = () => (
  <PageLayout title="Free Digital Tools - DEZO" h1="Free Marketing & Dev Tools" meta="Free marketing and web dev tools from DEZO: SEO checker, website audit, speed checker, project cost calculator.">
    <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
      {toolsData.map((tool) => (
        <div key={tool.id} className="bg-[var(--bg-card)] p-8 rounded-3xl border border-[var(--border-soft)] hover:border-[var(--primary)]/50 smooth-transition group relative overflow-hidden">
          <div className="mb-6 w-14 h-14 rounded-2xl bg-[var(--primary)]/10 text-[var(--primary)] flex items-center justify-center border border-[var(--primary)]/20 group-hover:scale-110 smooth-transition">
            {tool.icon === 'Search' && <Search size={24} />}
            {tool.icon === 'TrendingUp' && <TrendingUp size={24} />}
            {tool.icon === 'Zap' && <Zap size={24} />}
            {tool.icon === 'Code' && <Code size={24} />}
          </div>
          <h3 className="text-2xl font-black text-main-light mb-3">{tool.title}</h3>
          <p className="text-main-muted font-medium mb-8">{tool.description}</p>
          <button className="px-6 py-3 bg-[var(--primary)] text-[#070707] font-bold rounded-xl active:scale-95 smooth-transition w-full text-center">Launch Tool</button>
        </div>
      ))}
    </div>
  </PageLayout>
);

export const NewsPage = () => (
  <PageLayout title="Latest News & Updates - DEZO" h1="Company News & Updates" meta="Stay updated with the latest company news, announcements and product updates from DEZO.">
    <div className="flex flex-col gap-6">
      {newsUpdates.map((news) => (
        <div key={news.id} className="bg-[var(--bg-card)] p-6 md:p-8 rounded-2xl border border-[var(--border-soft)] hover:border-[var(--primary)]/30 smooth-transition flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2 text-xs font-bold uppercase tracking-widest text-main-muted">
              <span className="text-[var(--primary)] font-bold px-2 py-1 rounded bg-[var(--primary)]/10">{news.type}</span>
              <span>{news.date}</span>
            </div>
            <h3 className="text-xl font-bold text-main-light">{news.title}</h3>
          </div>
          <button className="text-sm font-bold text-[var(--primary)] self-start md:self-auto hover:underline">Read Update</button>
        </div>
      ))}
    </div>
  </PageLayout>
);

export const FaqPage = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  return (
    <PageLayout title="Frequently Asked Questions - DEZO" h1="Frequently Asked Questions" meta="Find answers to all your questions about DEZO's web development, SEO and digital marketing services.">
      <div className="space-y-4 max-w-3xl mx-auto">
        {faqData.map((faq, idx) => (
          <div key={idx} className="border border-[var(--border-soft)] rounded-2xl bg-[var(--bg-card)] overflow-hidden smooth-transition hover:border-[var(--primary)]/50">
            <button 
              className="w-full px-6 py-5 flex items-center justify-between font-bold text-left focus:outline-none"
              onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
            >
              <span className="text-lg text-[var(--text-main)] pr-8">{faq.q}</span>
              <div className={`w-8 h-8 rounded-full bg-[var(--bg-surface)] flex items-center justify-center border border-[var(--border-soft)] shrink-0 text-[var(--text-main)] smooth-transition ${openIndex === idx ? 'bg-[var(--primary)] text-[#070707] border-[var(--primary)] transform rotate-180' : ''}`}>
                <ChevronDown size={16} />
              </div>
            </button>
            <div className={`px-6 smooth-transition overflow-hidden ${openIndex === idx ? 'max-h-[500px] pb-5 opacity-100' : 'max-h-0 opacity-0'}`}>
              <p className="text-[var(--text-muted)] font-medium pb-2 text-base leading-relaxed">{faq.a}</p>
            </div>
          </div>
        ))}
      </div>
    </PageLayout>
  );
};

export const PricingPage = () => (
  <PageLayout title="Pricing & Packages - DEZO" h1="Transparent Pricing Plans" meta="View DEZO's transparent pricing plans for website development, SEO and digital marketing.">
    <div className="-mx-4 sm:-mx-8">
      <PricingSection />
      <ChallengeSection />
    </div>
  </PageLayout>
);

export const ResourcesPage = () => (
  <PageLayout title="Free Resources & Guides - DEZO" h1="Free Downloadable Resources" meta="Download free ebooks, templates, and checklists to help your digital marketing and web development reach new heights.">
    <div className="text-center text-main-muted py-20">
      <h3 className="text-2xl font-bold text-main-light mb-4">Resource Library Growing...</h3>
      <p>We are currently compiling premium checklists, templates, and ebooks. Check back soon for exclusive downloads.</p>
    </div>
  </PageLayout>
);

export const PrivacyPage = () => (
  <PageLayout title="Privacy Policy - DEZO" h1="Privacy Policy" meta="Privacy policy for DEZO.">
    <h3 className="text-xl font-bold text-main-light mb-4">1. Data Collection</h3>
    <p>We collect minimal personal data including name, email, and phone when you submit a lead form. We do not sell your personal data to third-party vendors.</p>
    <br/>
    <h3 className="text-xl font-bold text-main-light mb-4">2. Cookies</h3>
    <p>We use standard performance and tracking cookies (such as Google Analytics and Meta Pixel) on our website solely to measure advertising performance and user experience.</p>
  </PageLayout>
);

export const TermsPage = () => (
  <PageLayout title="Terms & Conditions - DEZO" h1="Terms & Conditions" meta="Terms and conditions for DEZO.">
    <h3 className="text-xl font-bold text-main-light mb-4">1. Services Representation</h3>
    <p>All development and marketing services are executed as per the mutual agreement finalized during project commencement. Timelines are estimations contingent on client asset delivery.</p>
    <br/>
    <h3 className="text-xl font-bold text-main-light mb-4">2. Refund Policy</h3>
    <p>Given the custom digital nature of our services, partial or full refunds are only processed at the discretion of management if a project is canceled prior to core development phasing.</p>
  </PageLayout>
);
