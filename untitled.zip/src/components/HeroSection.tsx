import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Code, Smartphone, Rocket, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AnimatedHeroVisual } from './AnimatedVisuals';

export const HeroSection = () => {
    return (
        <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-white pt-24 pb-16">
            <div className="hero-grid"></div>
            
            <div className="max-w-[90rem] mx-auto w-full px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-8 items-center relative z-10">
                <div className="flex flex-col items-start text-left pt-10 md:pt-0">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, ease: "easeOut" }}
                        className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-[#F7F9FC] border border-[#E5EAF2] text-[#5B6472] text-xs md:text-sm font-bold tracking-wide mb-6 shadow-sm"
                    >
                        <span className="w-2 h-2 rounded-full bg-[#1D4ED8] animate-pulse"></span>
                        <span>Premium Web Development & Marketing</span>
                    </motion.div>

                    <motion.h1 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.1, ease: "easeOut" }}
                        className="clamp-h1 text-[#0B1220] mb-6 leading-tight"
                    >
                        Build a Website That Looks Premium, Loads Fast, and Converts Visitors into Customers.
                    </motion.h1>

                    <motion.p 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
                        className="clamp-p max-w-2xl mb-8"
                    >
                        DEZO creates professional websites, SEO strategies, Meta Ads campaigns, and digital growth systems for businesses that want real results.
                    </motion.p>

                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
                        className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto"
                    >
                        <a href="#contact" onClick={(e) => {
                            if (window.location.pathname === '/') {
                                e.preventDefault();
                                document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                            }
                        }} className="btn-primary px-8 py-4 w-full sm:w-auto text-center text-[15px] hover:gap-2">
                            <span>Start Your Project</span>
                            <ArrowRight className="w-5 h-5 ml-2" />
                        </a>
                        <a href="#latest-work" onClick={(e) => {
                             if (window.location.pathname === '/') {
                                e.preventDefault();
                                document.getElementById('latest-work')?.scrollIntoView({ behavior: 'smooth' });
                            } else {
                                window.location.href = '/portfolio';
                            }
                        }} className="px-8 py-4 rounded-full font-bold bg-[#F7F9FC] border border-[#E5EAF2] hover:border-[#1D4ED8]/30 hover:bg-white text-[#0B1220] transition-all duration-300 w-full sm:w-auto text-center shadow-sm">
                            View Latest Work
                        </a>
                    </motion.div>

                    <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 1, delay: 0.6 }}
                        className="mt-12 flex items-center gap-6 text-[#8A94A6] font-medium text-sm"
                    >
                        <div className="flex items-center gap-2"><Zap className="w-5 h-5 text-[#F5B301]" /> Fast Delivery</div>
                        <div className="flex items-center gap-2"><Code className="w-5 h-5 text-[#1D4ED8]" /> Modern Tech Stack</div>
                    </motion.div>
                </div>

                <div className="relative w-full aspect-square md:aspect-video lg:aspect-square flex items-center justify-center">
                    <AnimatedHeroVisual />
                </div>
            </div>
        </section>
    );
};
