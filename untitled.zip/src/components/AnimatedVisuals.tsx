import React, { useState, useEffect } from 'react';
import { motion, useAnimation } from 'motion/react';
import { Code, TrendingUp, Presentation, LayoutDashboard, Database, Smartphone } from 'lucide-react';

export const AnimatedHeroVisual = () => {
    // Basic mouse tracking for parallax
    const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            setMousePos({
                x: (e.clientX / window.innerWidth - 0.5) * 20,
                y: (e.clientY / window.innerHeight - 0.5) * 20,
            });
        };
        window.addEventListener('mousemove', handleMouseMove);
        return () => window.removeEventListener('mousemove', handleMouseMove);
    }, []);

    return (
        <div className="relative w-full h-full max-h-[500px] border border-[#E5EAF2] rounded-[32px] overflow-hidden shadow-[0_20px_50px_rgba(15,23,42,0.08)] bg-[#F7F9FC] p-4 flex items-center justify-center perspective-1000">
            {/* Particles */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                {[...Array(6)].map((_, i) => (
                    <motion.div
                        key={i}
                        animate={{
                            y: [0, -20, 0],
                            opacity: [0.2, 0.5, 0.2],
                        }}
                        transition={{
                            duration: 3 + i,
                            repeat: Infinity,
                            ease: "easeInOut",
                            delay: i * 0.5
                        }}
                        className={`absolute rounded-full blur-md ${i % 2 === 0 ? 'bg-[#1D4ED8]' : 'bg-[#F5B301]'}`}
                        style={{
                            width: Math.random() * 60 + 20 + 'px',
                            height: Math.random() * 60 + 20 + 'px',
                            left: Math.random() * 100 + '%',
                            top: Math.random() * 100 + '%',
                            opacity: 0.1
                        }}
                    />
                ))}
            </div>

            {/* Central Browser Mockup */}
            <motion.div 
                className="relative z-10 w-[85%] h-[80%] bg-white rounded-xl shadow-[0_30px_60px_rgba(15,23,42,0.12)] border border-[#E5EAF2] flex flex-col overflow-hidden"
                animate={{
                    rotateX: mousePos.y * -0.5,
                    rotateY: mousePos.x * 0.5,
                }}
                transition={{ type: "spring", stiffness: 75, damping: 20 }}
            >
                {/* Browser Header */}
                <div className="h-8 bg-[#F7F9FC] border-b border-[#E5EAF2] flex items-center px-4 gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-[#DC2626]/20 border border-[#DC2626]/40"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-[#F5B301]/20 border border-[#F5B301]/40"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-[#16A34A]/20 border border-[#16A34A]/40"></div>
                    <div className="ml-4 w-32 h-3 bg-white border border-[#E5EAF2] rounded-full"></div>
                </div>
                
                {/* Browser Content Layout */}
                <div className="flex-1 p-4 grid grid-cols-12 gap-3 bg-white">
                    {/* Sidebar */}
                    <div className="col-span-3 border-r border-[#E5EAF2] pr-3 space-y-3 hidden sm:block">
                        <div className="h-4 w-20 bg-[#1D4ED8]/10 rounded mb-6"></div>
                        <div className="h-3 w-full bg-[#F7F9FC] rounded"></div>
                        <div className="h-3 w-5/6 bg-[#F7F9FC] rounded"></div>
                        <div className="h-3 w-4/6 bg-[#F7F9FC] rounded"></div>
                        
                        <div className="mt-8 space-y-2">
                            <div className="w-full h-8 rounded bg-[#F7F9FC] flex items-center px-2 gap-2">
                                <LayoutDashboard size={12} className="text-[#8A94A6]"/>
                                <div className="h-2 w-12 bg-[#E5EAF2] rounded"></div>
                            </div>
                            <div className="w-full h-8 rounded bg-[#1D4ED8]/5 border border-[#1D4ED8]/10 flex items-center px-2 gap-2">
                                <TrendingUp size={12} className="text-[#1D4ED8]"/>
                                <div className="h-2 w-16 bg-[#1D4ED8]/20 rounded"></div>
                            </div>
                        </div>
                    </div>
                    
                    {/* Main Area */}
                    <div className="col-span-12 sm:col-span-9 flex flex-col gap-3">
                        <div className="flex gap-3 h-24">
                            <motion.div 
                                animate={{ y: [0, -5, 0] }}
                                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                                className="flex-1 bg-gradient-to-br from-[#1D4ED8] to-[#0F2E8A] rounded-lg p-3 relative overflow-hidden"
                            >
                                <div className="absolute -right-2 -top-2 w-16 h-16 bg-white/10 rounded-full blur-xl"></div>
                                <div className="text-white text-[10px] font-bold opacity-70 mb-1">Total Revenue</div>
                                <div className="text-white font-black text-lg">$24,592</div>
                                <svg className="absolute bottom-2 right-2 w-12 h-6" viewBox="0 0 50 20">
                                    <path d="M0 20 L10 15 L20 18 L30 8 L40 12 L50 2" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                                    <path d="M40 12 L50 2 L50 20 L40 20" fill="rgba(255,255,255,0.1)"/>
                                </svg>
                            </motion.div>
                            <div className="flex-1 bg-[#F5B301]/10 border border-[#F5B301]/20 rounded-lg p-3 relative">
                                  <div className="text-[#0B1220] text-[10px] font-bold mb-1">Conversion Rate</div>
                                  <div className="text-[#0B1220] font-black text-lg flex items-center gap-1">
                                      4.2% <span className="text-[#16A34A] text-xs">+1.2%</span>
                                  </div>
                                  <div className="absolute bottom-3 right-3 w-6 h-6 rounded-full bg-white border border-[#E5EAF2] flex items-center justify-center">
                                      <TrendingUp size={12} className="text-[#1D4ED8]"/>
                                  </div>
                            </div>
                        </div>

                        {/* Editor Mockup */}
                        <motion.div 
                             animate={{ y: [0, 5, 0] }}
                             transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                             className="flex-1 bg-[#0B1220] rounded-lg p-3 font-mono text-[8px] text-[#8A94A6] leading-relaxed shadow-inner border border-[#1D4ED8]/20"
                        >
                            <div className="flex items-center gap-1.5 mb-2 border-b border-white/10 pb-1">
                                <Code size={10} className="text-[#1D4ED8]"/>
                                <span className="text-white/70">app.tsx</span>
                            </div>
                            <div><span className="text-[#F5B301]">import</span> {'{'} <span className="text-[#1D4ED8]">useState</span> {'}'} <span className="text-[#F5B301]">from</span> <span className="text-[#16A34A]">'react'</span>;</div>
                            <div className="mt-1"><span className="text-[#F5B301]">function</span> <span className="text-[#1D4ED8]">App</span>() {'{'}</div>
                            <div className="ml-2"><span className="text-[#F5B301]">const</span> [data, setData] = <span className="text-[#1D4ED8]">useState</span>(null);</div>
                            <div className="ml-2 mt-1"><span className="text-[#F5B301]">return</span> (</div>
                            <div className="ml-4 text-[#1D4ED8]">{'<Container>'}</div>
                            <div className="ml-6 text-white/90 font-bold">Build Your Digital Future.</div>
                            <div className="ml-4 text-[#1D4ED8]">{'</Container>'}</div>
                            <div className="ml-2">);</div>
                            <div>{'}'}</div>
                        </motion.div>
                    </div>
                </div>
            </motion.div>

            {/* Floating Assets */}
            <motion.div 
               animate={{ 
                   y: [0, -15, 0],
                   rotateZ: mousePos.x * 0.2
               }}
               transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
               className="absolute top-12 -left-6 md:-left-4 z-20 bg-white p-3 rounded-xl shadow-[0_15px_30px_rgba(15,23,42,0.1)] border border-[#E5EAF2] flex items-center gap-3 backdrop-blur-md"
            >
                <div className="w-8 h-8 rounded-lg bg-[#1D4ED8]/10 text-[#1D4ED8] flex items-center justify-center">
                    <Code size={16}/>
                </div>
                <div>
                    <div className="text-[9px] font-bold text-[#8A94A6] uppercase tracking-wider">Frontend</div>
                    <div className="text-xs font-black text-[#0B1220]">React & Next.js</div>
                </div>
            </motion.div>

            <motion.div 
               animate={{ 
                   y: [0, 15, 0],
                   rotateZ: mousePos.y * -0.2
               }}
               transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
               className="absolute bottom-12 -right-4 md:-right-2 z-20 bg-white p-3 rounded-xl shadow-[0_15px_30px_rgba(15,23,42,0.1)] border border-[#E5EAF2] flex items-center gap-3 backdrop-blur-md"
            >
                <div className="w-8 h-8 rounded-lg bg-[#F5B301]/10 text-[#F5B301] flex items-center justify-center">
                    <TrendingUp size={16}/>
                </div>
                <div>
                    <div className="text-[9px] font-bold text-[#8A94A6] uppercase tracking-wider">Marketing</div>
                    <div className="text-xs font-black text-[#0B1220]">SEO Growth</div>
                </div>
            </motion.div>

             <motion.div 
               animate={{ 
                   scale: [1, 1.05, 1],
                   opacity: [0.8, 1, 0.8]
               }}
               transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
               className="absolute -top-4 right-10 z-0 w-24 h-24 bg-gradient-to-br from-[#1D4ED8]/20 to-[#F5B301]/20 rounded-full blur-2xl"
            />
        </div>
    );
};

export const DashboardPreviewVisual = () => {
    return (
        <div className="relative bg-white border border-[#E5EAF2] rounded-2xl overflow-hidden shadow-2xl p-2 aspect-[4/3] flex flex-col group">
             <div className="flex items-center gap-2 px-3 py-2 border-b border-[#E5EAF2]">
                <div className="flex gap-1.5"><div className="w-3 h-3 rounded-full bg-red-400"></div><div className="w-3 h-3 rounded-full bg-yellow-400"></div><div className="w-3 h-3 rounded-full bg-green-400"></div></div>
                <div className="flex-1"></div>
                <div className="w-32 h-3 bg-[#F7F9FC] border border-[#E5EAF2] rounded-full"></div>
                <div className="flex-1"></div>
             </div>
             <div className="flex-1 bg-[#F7F9FC]/50 relative p-4 flex gap-4 overflow-hidden">
                  <div className="w-1/3 bg-white rounded-lg border border-[#E5EAF2] p-4 flex flex-col gap-3">
                       <motion.div animate={{ width: ['40%', '75%', '50%'] }} transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }} className="h-6 w-3/4 bg-[#1D4ED8]/10 rounded mb-2"></motion.div>
                       <div className="space-y-2 flex-1">
                           {[...Array(5)].map((_,i) => (
                               <div key={i} className="flex gap-2 items-center">
                                   <div className="w-6 h-6 rounded bg-[#F7F9FC] shrink-0"></div>
                                   <div className="h-3 w-full bg-[#E5EAF2]/50 rounded"></div>
                               </div>
                           ))}
                       </div>
                       <div className="h-20 w-full bg-[#1D4ED8] rounded-xl flex items-center justify-center relative overflow-hidden">
                            <div className="absolute inset-0 bg-gradient-to-tr from-transparent to-white/20"></div>
                            <div className="w-8 h-8 rounded-full bg-white/20"></div>
                       </div>
                  </div>
                  <div className="flex-1 flex flex-col gap-4">
                       <motion.div 
                          className="h-1/2 bg-white rounded-lg border border-[#E5EAF2] p-4 flex items-end gap-2 overflow-hidden"
                          whileHover={{ scale: 1.02 }}
                       >
                           {[...Array(8)].map((_, i) => (
                               <motion.div 
                                   key={i}
                                   initial={{ height: '20%' }}
                                   animate={{ height: `${20 + Math.random() * 80}%` }}
                                   transition={{ duration: 2, repeat: Infinity, repeatType: "mirror", delay: i * 0.1 }}
                                   className={`flex-1 rounded-t-sm ${i % 3 === 0 ? 'bg-[#1D4ED8]' : 'bg-[#1D4ED8]/20'}`}
                               ></motion.div>
                           ))}
                       </motion.div>
                       <div className="h-1/2 flex gap-4">
                           <div className="flex-1 bg-[#F5B301]/10 border border-[#F5B301]/20 rounded-lg p-3 relative overflow-hidden">
                               <div className="w-8 h-8 rounded-full border-[3px] border-[#F5B301] border-t-transparent animate-spin"></div>
                           </div>
                           <div className="flex-1 bg-white border border-[#E5EAF2] rounded-lg p-4 flex flex-col justify-between">
                                <div className="h-3 w-full bg-[#E5EAF2]/50 rounded"></div>
                                <div className="h-3 w-4/5 bg-[#E5EAF2]/50 rounded mb-auto mt-2"></div>
                                <div className="flex gap-2">
                                    <div className="w-6 h-6 rounded-full bg-[#F7F9FC]"></div>
                                    <div className="w-6 h-6 rounded-full bg-[#F7F9FC]"></div>
                                </div>
                           </div>
                       </div>
                  </div>
             </div>
        </div>
    );
};

export const MarketingDashboardVisual = () => {
    return (
        <div className="relative w-full h-full min-h-[300px] bg-gradient-to-br from-[#1D4ED8] to-[#0F2E8A] overflow-hidden rounded-2xl flex items-center justify-center group p-8">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
            
            <div className="w-full max-w-sm">
                <motion.div 
                    animate={{ y: [-5, 5, -5] }} 
                    transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                    className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 shadow-2xl relative z-10"
                >
                    <div className="flex justify-between items-center mb-6">
                        <div className="h-4 w-24 bg-white/30 rounded"></div>
                        <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                            <TrendingUp size={16} className="text-white" />
                        </div>
                    </div>
                    
                    <div className="space-y-4">
                        <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                            <motion.div animate={{ width: ['30%', '80%', '50%'] }} transition={{ duration: 5, repeat: Infinity }} className="h-full bg-[#F5B301]"></motion.div>
                        </div>
                        <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                            <motion.div animate={{ width: ['60%', '40%', '90%'] }} transition={{ duration: 6, repeat: Infinity }} className="h-full bg-[#16A34A]"></motion.div>
                        </div>
                        <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                            <motion.div animate={{ width: ['40%', '70%', '30%'] }} transition={{ duration: 4.5, repeat: Infinity }} className="h-full bg-[#1D4ED8]"></motion.div>
                        </div>
                    </div>
                    
                    <div className="mt-8 flex justify-between gap-4">
                        <div className="h-16 flex-1 bg-white/5 rounded-xl border border-white/10 flex flex-col justify-center items-center gap-1">
                            <div className="text-white/50 text-[10px] uppercase font-bold">Leads</div>
                            <div className="text-white font-black text-lg">1,204</div>
                        </div>
                        <div className="h-16 flex-1 bg-[#F5B301]/20 rounded-xl border border-[#F5B301]/30 flex flex-col justify-center items-center gap-1">
                            <div className="text-[#F5B301] text-[10px] uppercase font-bold">Conv. Rate</div>
                            <div className="text-[#F5B301] font-black text-lg">5.8%</div>
                        </div>
                    </div>
                </motion.div>
                
                <motion.div 
                    animate={{ rotate: 360 }} 
                    transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                    className="absolute -top-12 -right-12 w-48 h-48 border-[1px] border-dashed border-white/10 rounded-full z-0"
                ></motion.div>
                <motion.div 
                    animate={{ rotate: -360 }} 
                    transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
                    className="absolute -bottom-12 -left-12 w-32 h-32 border-[1px] border-dashed border-white/10 rounded-full z-0"
                ></motion.div>
            </div>
        </div>
    );
};
export const PortfolioImageWithFallback = ({ title, src, alt }: { title: string, src?: string, alt: string }) => {
    const [imgError, setImgError] = useState(false);

    if (!src || imgError) {
        return (
            <div className="w-full h-full bg-[#0B1220] p-4 flex flex-col relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-br from-[#1D4ED8]/20 to-[#0F2E8A]/20 pointer-events-none"></div>
                <div className="relative z-10 w-full h-4 flex items-center gap-1.5 mb-4 border-b border-white/10 pb-2">
                    <div className="w-2 h-2 rounded-full bg-[#DC2626]/50"></div>
                    <div className="w-2 h-2 rounded-full bg-[#F5B301]/50"></div>
                    <div className="w-2 h-2 rounded-full bg-[#16A34A]/50"></div>
                    <div className="ml-2 w-16 h-1.5 bg-white/10 rounded-full"></div>
                </div>
                <div className="flex-1 flex flex-col gap-3 relative z-10">
                   <div className="h-6 w-3/4 bg-white/10 rounded"></div>
                   <div className="h-full flex gap-3">
                       <div className="w-1/3 flex flex-col gap-2">
                            <div className="h-3 w-full bg-white/10 rounded"></div>
                            <div className="h-3 w-5/6 bg-white/10 rounded"></div>
                            <div className="mt-auto h-12 w-full border border-[#1D4ED8]/30 bg-[#1D4ED8]/10 rounded flex items-center justify-center">
                                <div className="text-[#1D4ED8] text-[8px] font-bold uppercase">{title}</div>
                            </div>
                       </div>
                       <div className="w-2/3 bg-white/5 rounded border border-white/10 relative overflow-hidden group-hover:bg-white/10 smooth-transition flex flex-col items-center justify-center">
                            <LayoutDashboard size={24} className="text-[#8A94A6] mb-2 opacity-30 group-hover:opacity-100 smooth-transition group-hover:text-[#F5B301]" />
                            <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest group-hover:text-white/80">Preview Interface</div>
                       </div>
                   </div>
                </div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 smooth-transition scale-90 group-hover:scale-100 bg-[#1D4ED8] text-white text-xs font-bold px-4 py-2 rounded-full z-20 shadow-lg">
                    View Project Details
                </div>
            </div>
        );
    }
    
    return (
        <img 
            src={src} 
            alt={alt} 
            className="w-full h-full object-cover group-hover:scale-105 smooth-transition duration-700" 
            loading="lazy" 
            onError={() => setImgError(true)} 
        />
    );
};

export const AnimatedServiceIcon = ({ icon, color }: { icon: React.ReactNode, color: string }) => {
    return (
        <motion.div 
           whileHover={{ scale: 1.1, rotate: 5 }}
           transition={{ type: "spring", stiffness: 300, damping: 20 }}
           className={`w-14 h-14 rounded-xl ${color} flex items-center justify-center mb-6 relative group isolate transition-all duration-300`}
        >
            <div className={`absolute inset-0 rounded-xl opacity-0 group-hover:opacity-20 blur-md transition-opacity duration-500 scale-110 ${color.replace('/10', '')}`}></div>
            <motion.div 
               animate={{ y: [-2, 2, -2] }}
               transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
               className="relative z-10"
            >
               {icon}
            </motion.div>
        </motion.div>
    );
};
export const ContactBackgroundVisual = () => {
    return (
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none opacity-40">
            {/* Grid Pattern */}
            <div className="absolute inset-0" style={{
                backgroundImage: 'linear-gradient(to right, rgba(29, 78, 216, 0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(29, 78, 216, 0.05) 1px, transparent 1px)',
                backgroundSize: '40px 40px'
            }}></div>
            
            {/* Animated Gradient Blob */}
            <motion.div 
               animate={{ 
                   scale: [1, 1.2, 1],
                   opacity: [0.3, 0.5, 0.3],
                   x: [0, 50, 0]
               }}
               transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
               className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-[#1D4ED8]/10 to-transparent rounded-full blur-3xl"
            />
            
            <motion.div 
               animate={{ 
                   scale: [1, 1.3, 1],
                   opacity: [0.2, 0.4, 0.2],
                   x: [0, -30, 0]
               }}
               transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
               className="absolute bottom-0 left-0 w-80 h-80 bg-gradient-to-tr from-[#F5B301]/10 to-transparent rounded-full blur-3xl"
            />
        </div>
    );
};
export const AnimatedAgencyWorkflow = () => {
    return (
        <div className="relative w-full h-64 md:h-80 bg-white rounded-3xl border border-[#E5EAF2] overflow-hidden flex items-center justify-center p-4">
            
            <div className="relative z-10 w-full h-full max-w-2xl flex items-center justify-between">
                {[
                    { label: "Strategy", delay: 0 },
                    { label: "Design", delay: 1 },
                    { label: "Dev", delay: 2 },
                    { label: "Marketing", delay: 3 },
                    { label: "Growth", delay: 4 },
                ].map((item, i) => (
                    <motion.div 
                        key={i}
                        animate={{ y: [-5, 5, -5] }}
                        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: item.delay * 0.5 }}
                        className="flex flex-col items-center gap-3 relative z-10"
                    >
                        <div className="w-12 h-12 md:w-16 md:h-16 rounded-2xl bg-white border border-[#E5EAF2] shadow-sm flex items-center justify-center text-[#1D4ED8]">
                            <LayoutDashboard size={20} />
                        </div>
                        <div className="text-[9px] md:text-xs font-bold text-[#0B1220] uppercase tracking-wider">{item.label}</div>
                    </motion.div>
                ))}
                
                {/* Connecting Lines */}
                <div className="absolute top-1/2 left-[10%] right-[10%] h-[2px] bg-gradient-to-r from-transparent via-[#1D4ED8]/20 to-transparent -translate-y-1/2 -mt-[14px] z-0">
                    <motion.div 
                        animate={{ left: ['0%', '100%'] }}
                        transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
                        className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-[#1D4ED8] blur-[1px]"
                    ></motion.div>
                </div>
            </div>
        </div>
    );
};
