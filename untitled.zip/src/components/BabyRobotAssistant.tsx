import { useEffect, useState } from "react";
import "./BabyRobotAssistant.css";

export default function BabyRobotAssistant() {
  const [scrolling, setScrolling] = useState(false);

  useEffect(() => {
    let timer: any;

    const handleScroll = () => {
      setScrolling(true);
      clearTimeout(timer);
      timer = setTimeout(() => {
        setScrolling(false);
      }, 1200);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      window.removeEventListener("scroll", handleScroll);
      clearTimeout(timer);
    };
  }, []);

  return (
    <div className={`baby-robot-wrap ${scrolling ? "peek-out" : "peek-in"}`}>
      <div className="robot-hand"></div>

      <div className="baby-robot">
        <div className="robot-antenna"></div>

        <div className="robot-head">
          <div className="robot-glow"></div>

          <div className="robot-eyes">
            <span></span>
            <span></span>
          </div>

          <div className="robot-smile"></div>
        </div>

        <div className="robot-body">
          <div className="robot-core"></div>
        </div>

        <div className="robot-arm robot-arm-left"></div>
        <div className="robot-arm robot-arm-right"></div>
      </div>

      <div className="robot-bubble">
        <span>{scrolling ? "Looking with you..." : "Hi, I’m DEZO bot"}</span>
      </div>
    </div>
  );
}
