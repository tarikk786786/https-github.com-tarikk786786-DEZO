import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';

export const useIntersectionObserver = (options: any = {}) => {
  const [isIntersecting, setIsIntersecting] = useState(false);
  const ref = useRef<any>(null);
  const optionsStr = JSON.stringify(options);

  useEffect(() => {
    const parsedOptions = JSON.parse(optionsStr);
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsIntersecting(true);
        if (parsedOptions.triggerOnce !== false) observer.unobserve(entry.target);
      } else if (parsedOptions.triggerOnce === false) {
        setIsIntersecting(false);
      }
    }, { threshold: 0, rootMargin: '50px 0px -50px 0px', ...parsedOptions });

    const currentRef = ref.current;
    if (currentRef) observer.observe(currentRef);
    return () => { if (currentRef) observer.unobserve(currentRef); };
  }, [optionsStr]);

  return [ref, isIntersecting] as const;
};

export const Reveal = ({ children, delay = 0, direction = 'up', className = '' }: any) => {
  const getVariants = () => {
    if (direction === 'up') return { hidden: { opacity: 0, y: 40, scale: 0.98 }, visible: { opacity: 1, y: 0, scale: 1 }};
    if (direction === 'down') return { hidden: { opacity: 0, y: -40, scale: 0.98 }, visible: { opacity: 1, y: 0, scale: 1 }};
    if (direction === 'left') return { hidden: { opacity: 0, x: 40, scale: 0.98 }, visible: { opacity: 1, x: 0, scale: 1 }};
    if (direction === 'right') return { hidden: { opacity: 0, x: -40, scale: 0.98 }, visible: { opacity: 1, x: 0, scale: 1 }};
    if (direction === 'scale') return { hidden: { opacity: 0, scale: 0.9 }, visible: { opacity: 1, scale: 1 }};
    if (direction === 'outward') return { hidden: { opacity: 0, scale: 1.05 }, visible: { opacity: 1, scale: 1 }};
    return { hidden: { opacity: 0 }, visible: { opacity: 1 }};
  };

  return (
    <motion.div
      variants={getVariants()}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-5%", amount: 0.1 }}
      transition={{ 
        duration: 0.8, 
        delay: delay / 1000, 
        ease: [0.16, 1, 0.3, 1],
        opacity: { duration: 0.6 }
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

export const FallbackImage = ({ src, alt, className, fallbackInitials }: any) => {
  const [error, setError] = useState(false);
  if (error) {
    return (
      <div className={`${className} luxury-card border border-[var(--border-soft)] flex flex-col items-center justify-center text-[var(--text-main)] font-black tracking-widest relative overflow-hidden`}>
        <span className="relative z-10">{fallbackInitials}</span>
      </div>
    );
  }
  return <img loading="lazy" decoding="async" src={src} alt={alt} className={className} onError={() => setError(true)} />;
};
