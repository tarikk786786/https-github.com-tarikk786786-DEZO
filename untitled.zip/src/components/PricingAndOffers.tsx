import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, ShieldCheck, Zap, ArrowRight, Star, TrendingUp, ChevronDown, ChevronUp } from 'lucide-react';
import { Reveal } from '../components1';

// Custom Expandable Features Component for Pricing
const ExpandableFeatures = ({ features }: { features: string[] }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="flex-grow mt-2">
      <button 
        onClick={() => setIsOpen(!isOpen)} 
        className="text-[11px] font-bold uppercase tracking-widest text-main-muted hover:text-white flex items-center gap-1.5 smooth-transition mb-4 text-left"
      >
        {isOpen ? "Hide Advanced Features" : "Show Advanced Features"}
        {isOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.ul 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="space-y-4 mb-4"
          >
            {features.map((feature, idx) => (
              <li key={idx} className="flex gap-3 text-sm font-medium text-[#94A3B8]">
                <Check size={18} className="text-[#10B981]/50 shrink-0" />
                <span>{feature}</span>
              </li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </div>
  );
};

export const PricingSection = () => {
  return (
    <section id="pricing" className="py-24 lg:py-32 bg-[var(--bg-main)] border-y border-[var(--border-soft)] relative overflow-hidden">
      <div className="max-w-[90rem] mx-auto px-4 lg:px-8 relative z-10">
        <Reveal direction="up">
          <div className="text-center mb-16">
            <h2 className="clamp-h2 font-black text-[var(--text-main)] mb-4 tracking-tight">Simple & Transparent Pricing</h2>
            <p className="text-[var(--text-muted)] font-medium max-w-2xl mx-auto text-lg pt-2">
              Start with a clean business presence or scale into advanced custom websites when needed.
            </p>
          </div>
        </Reveal>

        <div className="grid lg:grid-cols-3 gap-6 md:gap-8">
          {/* Starter Website */}
          <Reveal direction="up" delay={100} className="h-full">
            <div className="bg-[var(--bg-card)] border border-[var(--border-soft)] p-6 sm:p-8 md:p-10 rounded-3xl h-full flex flex-col hover:-translate-y-2 smooth-transition shadow-lg hover:border-[var(--primary)]/50 relative overflow-hidden">
              <h3 className="text-2xl font-black text-[var(--text-main)] mb-2">Starter Website</h3>
              <p className="text-[var(--text-muted)] font-medium mb-6 text-sm">Perfect for establishing an online presence.</p>
              <div className="mb-8">
                <span className="text-2xl font-bold text-[var(--text-main)]">Contact for pricing</span>
              </div>
              <ul className="space-y-4 flex-grow mb-2">
                {[
                  "Clean, Modern Layout",
                  "Mobile & Tablet Responsive",
                  "Basic SEO Setup",
                ].map((feature, idx) => (
                  <li key={idx} className="flex gap-3 text-sm font-bold text-[var(--text-secondary)]">
                    <Check size={18} className="text-[#10B981] shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
                <ExpandableFeatures features={["Contact Form Integration", "Fast Loading Speed", "Social Media Links"]} />
              </ul>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => window.open('https://wa.me/919114411026?text=Hi%20DEZO%2C%20I%20want%20to%20know%20more%20about%20the%20Starter%20Website.', '_blank')}
                className="btn-primary w-full py-4 text-center mt-4"
              >
                Discuss Project
              </motion.button>
            </div>
          </Reveal>

          {/* Business Website Plan */}
          <Reveal direction="up" delay={200} className="h-full relative z-20">
            <div className="bg-[var(--bg-card)] border border-[var(--primary)] p-6 sm:p-8 md:p-10 rounded-3xl h-full flex flex-col relative z-30 transform md:scale-105 shadow-lg">
              <div className="absolute top-0 right-0 bg-[var(--primary)] text-[#070707] text-xs font-black uppercase tracking-wider py-1.5 px-4 rounded-bl-xl rounded-tr-3xl shadow-sm">
                Most Popular
              </div>
              <h3 className="text-2xl font-black text-[var(--text-main)] mb-2 pt-2">Business Website</h3>
              <p className="text-[var(--text-muted)] font-medium mb-6 text-sm">For growing brands that need more features.</p>
              <div className="mb-8">
                <span className="text-2xl font-bold text-[var(--text-main)]">Contact for pricing</span>
              </div>
              <ul className="space-y-4 flex-grow mb-2">
                {[
                  "Custom Multi-Page Design",
                  "Advanced SEO Setup",
                  "Product or Service Catalogs"
                ].map((feature, idx) => (
                  <li key={idx} className="flex gap-3 text-sm font-bold text-[var(--text-secondary)]">
                    <Check size={18} className="text-[var(--primary)] shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
                <ExpandableFeatures features={["WhatsApp Chat Integration", "Custom Contact Forms", "Google Analytics Setup", "Blog Section", "Fast Performance Optimization"]} />
              </ul>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => window.open('https://wa.me/919114411026?text=Hi%20DEZO%2C%20I%20want%20to%20discuss%20a%20Business%20Website.', '_blank')}
                className="btn-primary w-full py-4 text-center mt-4"
              >
                Discuss Project
              </motion.button>
            </div>
          </Reveal>

          {/* Growth Website Plan */}
          <Reveal direction="up" delay={300} className="h-full">
            <div className="bg-[var(--bg-card)] border border-[var(--border-soft)] p-6 sm:p-8 md:p-10 rounded-3xl h-full flex flex-col hover:-translate-y-2 smooth-transition shadow-lg hover:border-[var(--primary)]/50 relative overflow-hidden">
              <h3 className="text-2xl font-black text-[var(--text-main)] mb-2">Growth Website</h3>
              <p className="text-[var(--text-muted)] font-medium mb-6 text-sm">Full marketing implementation and complex structures.</p>
              <div className="mb-8">
                <span className="text-2xl font-bold text-[var(--text-main)]">Contact for pricing</span>
              </div>
              <ul className="space-y-4 flex-grow mb-2">
                {[
                  "E-commerce or Custom Database",
                  "Marketing Automation setup",
                  "Lead Generation Funnels",
                ].map((feature, idx) => (
                  <li key={idx} className="flex gap-3 text-sm font-bold text-[var(--text-secondary)]">
                    <Check size={18} className="text-[#10B981] shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
                <ExpandableFeatures features={["Payment Gateway Integration", "User Login/Dashboards", "API Connections", "Conversion Rate Optimization", "Premium Security Features"]} />
              </ul>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => window.open('https://wa.me/919114411026?text=Hi%20DEZO%2C%20I%20need%20a%20Growth%20Website%20with%20custom%20features.', '_blank')}
                className="w-full py-4 text-center btn-primary mt-4"
              >
                Request Quote
              </motion.button>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
};

export const ChallengeSection = () => {
  return (
    <section className="py-24 bg-[var(--primary)] relative overflow-hidden">
      <div className="absolute inset-0 bg-black/10 mix-blend-overlay pointer-events-none"></div>

      <div className="max-w-4xl mx-auto px-4 lg:px-8 relative z-10 text-center">
        <Reveal direction="up">
          <h2 className="clamp-h2 font-black text-[#070707] mb-6 tracking-tight">The DEZO Quality Promise</h2>
          <p className="text-lg md:text-xl text-[#070707]/90 font-medium leading-relaxed mb-6 max-w-3xl mx-auto">
            We actively challenge poorly designed websites, slow load times, confusing user interfaces, and weak mobile experiences.
          </p>
          <p className="text-base md:text-lg text-[#070707]/80 font-medium leading-relaxed mb-10 max-w-3xl mx-auto">
            If your existing website isn’t building trust, loading instantly, and converting visitors into leads, we will rebuild it stronger. We stand by our commitment: if you find equivalent premium design, technical infrastructure, and business-focused execution at a better value, we will match it and add extra services at no cost.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <div className="bg-white/20 border border-[#070707]/10 px-6 py-4 rounded-full flex gap-3 items-center">
              <ShieldCheck className="text-[#070707]" size={24} />
              <span className="font-bold text-[#070707] text-sm md:text-base">Premium Design Quality</span>
            </div>
            <div className="bg-white/20 border border-[#070707]/10 px-6 py-4 rounded-full flex gap-3 items-center">
              <Zap className="text-[#070707]" size={24} />
              <span className="font-bold text-[#070707] text-sm md:text-base">Built for Speed & SEO</span>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export const DigitalMarketingSection = () => {
  return (
    <section className="py-24 bg-[var(--bg-main)] border-y border-[var(--border-soft)] overflow-hidden relative">
      <div className="max-w-[90rem] mx-auto px-4 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <Reveal direction="left">
            <div>
              <div className="inline-block px-4 py-1.5 bg-[var(--primary)] text-[#070707] font-bold text-xs uppercase tracking-widest rounded-full mb-6">
                Included Value
              </div>
              <h2 className="clamp-h2 font-black text-[var(--text-main)] mb-6 leading-tight">Free Digital Marketing Guidance</h2>
              <p className="text-lg text-[var(--text-secondary)] leading-relaxed mb-8">
                A great website is just the beginning. With selected website packages, we provide free basic guidance on how to grow your business online and get more leads using digital marketing.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-4 mb-10">
                {[
                  "Social Media Setup Tips",
                  "Local SEO Best Practices",
                  "Lead Generation Strategy",
                  "Meta Ads Fundamentals"
                ].map((item, idx) => (
                  <div key={idx} className="bg-[var(--bg-card)] p-4 rounded-2xl flex items-center gap-3 border border-[var(--border-soft)]">
                    <div className="w-8 h-8 rounded-full bg-[var(--primary)]/10 flex items-center justify-center text-[var(--primary)] shrink-0">
                      <Star size={14} className="fill-current text-[var(--primary)]" />
                    </div>
                    <span className="font-bold text-[var(--text-main)] text-sm">{item}</span>
                  </div>
                ))}
              </div>
              
              <a href="#contact" className="inline-flex items-center gap-2 font-bold text-[var(--primary)] hover:gap-4 smooth-transition">
                Claim Your Free Guidance <ArrowRight size={20} />
              </a>
            </div>
          </Reveal>
          
          <Reveal direction="right" delay={200} className="relative hidden lg:block">
            <img 
              src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800" 
              alt="Digital Marketing Growth" 
              loading="lazy"
              decoding="async"
              className="rounded-[2.5rem] shadow-xl relative z-10 object-cover aspect-video border border-[var(--border-soft)]"
            />
            <div className="absolute -bottom-8 -left-8 bg-[var(--bg-card)] p-6 rounded-3xl shadow-lg z-20 border border-[var(--border-soft)] flex gap-4 items-center">
              <div className="w-12 h-12 bg-[#10B981]/10 rounded-full flex items-center justify-center text-[#10B981]">
                <TrendingUp size={24} />
              </div>
              <div>
                <p className="font-black text-[var(--text-main)] text-lg">Growth Strategy</p>
                <p className="text-sm font-bold text-[var(--text-muted)]">Free with packages</p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}

export const GrowthOffersSection = () => {
  const offers = [
    { title: "Starter Website", price: "₹4,999", bestFor: "Establishing online trust", benefit: "Professional business presence", features: ["Premium Design", "Mobile-First Layout", "WhatsApp CTA"] },
    { title: "Landing Page for Ads", price: "₹3,999", bestFor: "Meta/Google Ads traffic", benefit: "High conversion rates", features: ["Fast Loading", "Conversion Copy", "Lead Form"] },
    { title: "SEO-Ready Website", price: "₹5,999", bestFor: "Organic Google ranking", benefit: "Long-term traffic growth", features: ["On-Page SEO", "Fast Speeds", "Schema Markup"] },
    { title: "Business Growth Website", price: "₹9,999", bestFor: "Scaling businesses", benefit: "Advanced branding & trust", features: ["Custom Branding", "Lead Gen Focus", "Analytics Setup"] },
    { title: "Ecommerce Website", price: "₹14,999", bestFor: "Selling products online", benefit: "Automated sales & payments", features: ["Payment Gateway", "Product Pages", "Cart System"] },
    { title: "Platform / Database Website", price: "₹19,999+", bestFor: "Custom web apps & portals", benefit: "Complex logic & data", features: ["Backend Database", "Admin Panel", "User Login"] },
    { title: "SaaS / Startup MVP", price: "₹24,999+", bestFor: "Tech startups", benefit: "Fast go-to-market", features: ["User Profiles", "Subscription Ready", "Scalable Architecture"] },
    { title: "Add Advanced Features", price: "from ₹3,000", bestFor: "Extending functionality", benefit: "Custom modules & tools", features: ["API Integrations", "Custom Forms", "Automations"] },
    { title: "Digital Marketing Setup", price: "₹4,999/mo", bestFor: "New websites", benefit: "Instant online visibility", features: ["Meta Ads Setup", "Google Business", "SEO Basics"] },
    { title: "SEO & Content Growth", price: "₹9,999/mo", bestFor: "Organic visibility", benefit: "Long-lasting traffic", features: ["Keyword Strategy", "Blog Content", "Backlink Profile"] },
    { title: "Managed Meta Ads", price: "10% of Ad Spend", bestFor: "Scaling sales", benefit: "High ROAS & Leads", features: ["Ad Creatives", "A/B Testing", "Conversion Tracking"] },
    { title: "Full Scale Agency Growth", price: "Custom", bestFor: "Established brands", benefit: "Dominate the market", features: ["Dedicated Team", "Omnichannel Ads", "CRM Integration"] }
  ];

  return (
    <section id="offers" className="py-24 bg-[var(--bg-main)] border-y border-[var(--border-soft)] overflow-hidden">
      <div className="max-w-[90rem] mx-auto px-4 lg:px-8">
        <Reveal direction="up">
          <div className="text-center mb-16">
            <h2 className="clamp-h2 font-black text-white mb-4 tracking-tight">Comprehensive Digital Growth Plans</h2>
            <p className="text-[var(--text-muted)] font-medium max-w-2xl mx-auto text-lg pt-2">
              From high-converting landing pages to full-scale SaaS platforms and aggressive digital marketing setups. Find the perfect plan for your level of growth.
            </p>
          </div>
        </Reveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {offers.map((offer, idx) => (
            <Reveal key={idx} direction="up" delay={idx * 50}>
              <motion.div whileHover={{ y: -5 }} className="bg-[var(--bg-card)] border border-[var(--border-soft)] p-6 rounded-2xl h-full flex flex-col hover:shadow-lg hover:shadow-[var(--primary)]/10 smooth-transition hover:border-[var(--primary)]/30 group">
                <div className="mb-4">
                  <h3 className="text-xl font-black text-white mb-1">{offer.title}</h3>
                  <div className="text-2xl font-black text-[var(--primary)]">{offer.price}</div>
                </div>
                <div className="text-sm font-medium text-[var(--text-secondary)] mb-4 border-b border-[var(--border-soft)] pb-4">
                  <span className="block mb-1"><strong>Best for:</strong> {offer.bestFor}</span>
                  <span className="block"><strong>Benefit:</strong> {offer.benefit}</span>
                </div>
                <ul className="space-y-3 flex-grow mb-6">
                  {offer.features.map((feature, i) => (
                    <li key={i} className="flex gap-2 text-sm font-bold text-white">
                      <Check size={16} className="text-[#10B981] shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => window.open(`https://wa.me/919114411026?text=Hi%20DEZO%2C%20I%20am%20interested%20in%20the%20${offer.title}%20plan.`, '_blank')}
                  className="w-full py-3 text-center text-sm text-[var(--text-main)] bg-[var(--bg-surface)] border border-[var(--border-soft)] hover:border-transparent hover:bg-[var(--primary)] hover:text-[#070707] smooth-transition font-bold rounded-xl mt-auto"
                >
                  Explore Plan
                </motion.button>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

